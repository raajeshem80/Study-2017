export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:8080',
  wsBaseUrl: 'http://localhost:8080',
  orderApiKey: 'change-me',
  defaultSymbol: 'RELIANCE'
};
