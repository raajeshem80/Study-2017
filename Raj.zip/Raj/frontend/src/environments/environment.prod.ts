export const environment = {
  production: true,
  apiBaseUrl: 'https://api.your-domain.com',
  wsBaseUrl: 'https://api.your-domain.com',
  orderApiKey: 'change-me',
  defaultSymbol: 'RELIANCE'
};
