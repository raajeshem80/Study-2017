import { Component } from '@angular/core';
import { MarketStateService } from '../core/services/market-state.service';

@Component({
  selector: 'app-signal-panel',
  templateUrl: './signal-panel.component.html',
  styleUrls: ['./signal-panel.component.css']
})
export class SignalPanelComponent {
  constructor(public readonly state: MarketStateService) {}

  colorFor(action: string): string {
    if (action === 'BUY') {
      return 'var(--accent)';
    }
    if (action === 'SELL') {
      return 'var(--warn)';
    }
    return '#5f6a66';
  }
}
