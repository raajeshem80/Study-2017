import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SignalPanelComponent } from './signal-panel.component';
import { MaterialModule } from '../shared/material.module';

@NgModule({
  declarations: [SignalPanelComponent],
  imports: [CommonModule, MaterialModule],
  exports: [SignalPanelComponent]
})
export class SignalPanelModule {}
