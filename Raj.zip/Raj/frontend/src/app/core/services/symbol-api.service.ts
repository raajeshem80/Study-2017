import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface SymbolMapResponse {
  symbol: string;
  kiteSymbol: string;
  upstoxSymbol: string;
}

@Injectable({ providedIn: 'root' })
export class SymbolApiService {
  constructor(private readonly http: HttpClient) {}

  map(symbol: string): Observable<SymbolMapResponse> {
    return this.http.get<SymbolMapResponse>(`${environment.apiBaseUrl}/api/symbols/map/${symbol}`);
  }
}
