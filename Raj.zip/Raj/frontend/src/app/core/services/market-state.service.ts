import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { BacktestResult } from '../../models/backtest.model';
import { LiveAnalysisResponse } from '../../models/live-analysis.model';
import { RuleDsl } from '../../models/rule-dsl.model';
import { Signal } from '../../models/signal.model';
import { TradePlan } from '../../models/trade-plan.model';

@Injectable({ providedIn: 'root' })
export class MarketStateService {
  readonly selectedBroker$ = new BehaviorSubject<string>('kite');
  readonly selectedSymbol$ = new BehaviorSubject<string>('RELIANCE');
  readonly watchlist$ = new BehaviorSubject<string[]>(['RELIANCE', 'TCS', 'INFY']);
  readonly analysis$ = new BehaviorSubject<LiveAnalysisResponse | null>(null);
  readonly signal$ = new BehaviorSubject<Signal | null>(null);
  readonly tradePlan$ = new BehaviorSubject<TradePlan | null>(null);
  readonly backtestResult$ = new BehaviorSubject<BacktestResult | null>(null);
  readonly activeRule$ = new BehaviorSubject<RuleDsl>({
    operator: 'AND',
    conditions: [
      { field: 'rsi', comparator: '>', value: '55' },
      { field: 'volume', comparator: '>', value: '100000' }
    ],
    groups: []
  });

  selectBroker(broker: string): void {
    this.selectedBroker$.next(broker);
  }

  selectSymbol(symbol: string): void {
    this.selectedSymbol$.next(symbol.toUpperCase());
  }

  setAnalysis(data: LiveAnalysisResponse): void {
    this.analysis$.next(data);
    this.signal$.next(data.signal);
    this.tradePlan$.next(data.tradePlan);
  }
}
