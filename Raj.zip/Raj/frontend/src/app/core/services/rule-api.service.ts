import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { RuleDsl } from '../../models/rule-dsl.model';

export interface RuleEvaluateRequest {
  name: string;
  symbol: string;
  rule: RuleDsl;
  context: Record<string, string | number | boolean>;
}

export interface RuleEvaluateResponse {
  matched: boolean;
  matchedClauses: string[];
}

@Injectable({ providedIn: 'root' })
export class RuleApiService {
  constructor(private readonly http: HttpClient) {}

  evaluate(payload: RuleEvaluateRequest): Observable<RuleEvaluateResponse> {
    return this.http.post<RuleEvaluateResponse>(`${environment.apiBaseUrl}/api/rules/evaluate`, payload);
  }
}
