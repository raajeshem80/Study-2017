import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { BacktestRequest, BacktestResult } from '../../models/backtest.model';

@Injectable({ providedIn: 'root' })
export class BacktestApiService {
  constructor(private readonly http: HttpClient) {}

  run(payload: BacktestRequest): Observable<BacktestResult> {
    return this.http.post<BacktestResult>(`${environment.apiBaseUrl}/api/backtest`, payload);
  }
}
