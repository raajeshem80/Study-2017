import { Injectable } from '@angular/core';
import { Client, IMessage } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import { BehaviorSubject } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Signal } from '../../models/signal.model';
import { TradePlan } from '../../models/trade-plan.model';

export interface TickMessage {
  version: string;
  broker: string;
  symbol: string;
  price: number;
  volume: number;
  timestamp: string;
}

@Injectable({ providedIn: 'root' })
export class WsService {
  private client?: Client;
  private connected = false;
  private readonly pendingSymbols = new Set<string>();
  private activeBroker = 'kite';

  readonly tick$ = new BehaviorSubject<TickMessage | null>(null);
  readonly signal$ = new BehaviorSubject<Signal | null>(null);
  readonly tradePlan$ = new BehaviorSubject<TradePlan | null>(null);

  connect(): void {
    if (this.connected) {
      return;
    }

    this.client = new Client({
      webSocketFactory: () => new SockJS(`${environment.wsBaseUrl}/ws`),
      reconnectDelay: 5000
    });

    this.client.onConnect = () => {
      this.connected = true;
      this.pendingSymbols.forEach((symbol) => this.subscribeInternal(this.activeBroker, symbol));
    };

    this.client.activate();
  }

  subscribeForSymbol(broker: string, symbol: string): void {
    this.activeBroker = broker;
    if (!this.client || !this.connected) {
      this.pendingSymbols.add(symbol);
      return;
    }
    this.subscribeInternal(broker, symbol);
  }

  private subscribeInternal(broker: string, symbol: string): void {
    if (!this.client) {
      return;
    }
    this.pendingSymbols.delete(symbol);
    this.client.subscribe(`/topic/ticks.${symbol}`, (message: IMessage) => {
      this.tick$.next(JSON.parse(message.body) as TickMessage);
    });
    this.client.subscribe(`/topic/signals.${symbol}`, (message: IMessage) => {
      this.signal$.next(JSON.parse(message.body) as Signal);
    });
    this.client.subscribe(`/topic/tradeplan.${symbol}`, (message: IMessage) => {
      this.tradePlan$.next(JSON.parse(message.body) as TradePlan);
    });

    this.client.publish({
      destination: '/app/watchlist',
      body: JSON.stringify({
        broker,
        symbols: [symbol]
      })
    });
  }

  disconnect(): void {
    this.connected = false;
    this.client?.deactivate();
  }
}
