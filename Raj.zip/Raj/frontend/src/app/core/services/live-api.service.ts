import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { LiveAnalysisResponse } from '../../models/live-analysis.model';

@Injectable({ providedIn: 'root' })
export class LiveApiService {
  constructor(private readonly http: HttpClient) {}

  analyze(broker: string, symbol: string): Observable<LiveAnalysisResponse> {
    return this.http.get<LiveAnalysisResponse>(`${environment.apiBaseUrl}/api/live/${broker}/${symbol}`);
  }
}
