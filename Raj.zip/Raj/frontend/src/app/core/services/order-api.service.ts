import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { OrderSide } from '../../models/trade-plan.model';

export interface PlaceOrderRequest {
  broker: string;
  symbol: string;
  accountId: string;
  side: OrderSide;
  quantity: number;
  orderType: 'MARKET' | 'LIMIT';
  price?: number;
}

export interface OrderResponse {
  orderId: string;
  broker: string;
  accountId: string;
  status: string;
  message: string;
  timestamp: string;
}

@Injectable({ providedIn: 'root' })
export class OrderApiService {
  constructor(private readonly http: HttpClient) {}

  place(payload: PlaceOrderRequest): Observable<OrderResponse> {
    return this.http.post<OrderResponse>(`${environment.apiBaseUrl}/api/orders/place`, payload);
  }

  cancel(orderId: string, broker: string, accountId: string): Observable<OrderResponse> {
    const params = new HttpParams().set('broker', broker).set('accountId', accountId);
    return this.http.post<OrderResponse>(`${environment.apiBaseUrl}/api/orders/${orderId}/cancel`, null, { params });
  }

  status(orderId: string, broker: string, accountId: string): Observable<OrderResponse> {
    const params = new HttpParams().set('broker', broker).set('accountId', accountId);
    return this.http.get<OrderResponse>(`${environment.apiBaseUrl}/api/orders/${orderId}`, { params });
  }
}
