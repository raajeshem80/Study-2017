import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RuleBuilderComponent } from './rule-builder.component';
import { MaterialModule } from '../shared/material.module';

@NgModule({
  declarations: [RuleBuilderComponent],
  imports: [CommonModule, FormsModule, MaterialModule],
  exports: [RuleBuilderComponent]
})
export class RuleBuilderModule {}
