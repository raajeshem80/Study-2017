import { Component } from '@angular/core';
import { MarketStateService } from '../core/services/market-state.service';
import { RuleApiService, RuleEvaluateResponse } from '../core/services/rule-api.service';
import { RuleCondition } from '../models/rule-dsl.model';

@Component({
  selector: 'app-rule-builder',
  templateUrl: './rule-builder.component.html',
  styleUrls: ['./rule-builder.component.css']
})
export class RuleBuilderComponent {
  ruleName = 'Default Momentum Rule';
  newCondition: RuleCondition = { field: 'rsi', comparator: '>', value: '55' };
  lastResult?: RuleEvaluateResponse;

  constructor(
    public readonly state: MarketStateService,
    private readonly ruleApiService: RuleApiService
  ) {}

  addCondition(): void {
    const rule = this.state.activeRule$.value;
    this.state.activeRule$.next({
      ...rule,
      conditions: [...rule.conditions, { ...this.newCondition }]
    });
    this.newCondition = { field: 'rsi', comparator: '>', value: '55' };
  }

  removeCondition(index: number): void {
    const rule = this.state.activeRule$.value;
    this.state.activeRule$.next({
      ...rule,
      conditions: rule.conditions.filter((_, idx) => idx !== index)
    });
  }

  evaluate(): void {
    const analysis = this.state.analysis$.value;
    if (!analysis) {
      return;
    }
    const context = {
      rsi: Number(analysis.indicators.rsi14),
      ema: Number(analysis.indicators.ema50),
      vwap: Number(analysis.indicators.vwap),
      atr: Number(analysis.indicators.atr14),
      score: analysis.signal.score,
      volume: 120000
    };
    this.ruleApiService.evaluate({
      name: this.ruleName,
      symbol: this.state.selectedSymbol$.value,
      rule: this.state.activeRule$.value,
      context
    }).subscribe((result) => {
      this.lastResult = result;
    });
  }
}
