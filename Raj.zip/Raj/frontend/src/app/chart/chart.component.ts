import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';
import { MarketStateService } from '../core/services/market-state.service';

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.css']
})
export class ChartComponent implements AfterViewInit, OnDestroy {
  @ViewChild('tvContainer', { static: true }) tvContainer!: ElementRef<HTMLDivElement>;
  private readonly subscriptions = new Subscription();

  constructor(private readonly state: MarketStateService) {}

  ngAfterViewInit(): void {
    this.subscriptions.add(
      this.state.selectedSymbol$.subscribe((symbol) => this.renderTradingView(symbol))
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  private renderTradingView(symbol: string): void {
    this.tvContainer.nativeElement.innerHTML = '';
    const wrapper = document.createElement('div');
    wrapper.className = 'tradingview-widget-container__widget';
    const script = document.createElement('script');
    script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js';
    script.type = 'text/javascript';
    script.async = true;
    script.innerHTML = JSON.stringify({
      autosize: true,
      symbol: `NSE:${symbol}`,
      interval: '5',
      timezone: 'Asia/Kolkata',
      theme: 'light',
      style: '1',
      locale: 'en',
      allow_symbol_change: true,
      support_host: 'https://www.tradingview.com'
    });
    this.tvContainer.nativeElement.appendChild(wrapper);
    this.tvContainer.nativeElement.appendChild(script);
  }
}
