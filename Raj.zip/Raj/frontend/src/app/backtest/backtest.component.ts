import { Component } from '@angular/core';
import { BacktestApiService } from '../core/services/backtest-api.service';
import { MarketStateService } from '../core/services/market-state.service';

@Component({
  selector: 'app-backtest',
  templateUrl: './backtest.component.html',
  styleUrls: ['./backtest.component.css']
})
export class BacktestComponent {
  timeframe = '5m';
  from = '2025-01-01T09:15:00Z';
  to = '2025-01-31T15:30:00Z';
  capital = 100000;
  loading = false;
  readonly displayedColumns = ['entryTime', 'side', 'entry', 'exit', 'quantity', 'pnl'];

  constructor(
    public readonly state: MarketStateService,
    private readonly backtestApiService: BacktestApiService
  ) {}

  run(): void {
    this.loading = true;
    this.backtestApiService.run({
      broker: this.state.selectedBroker$.value,
      symbol: this.state.selectedSymbol$.value,
      timeframe: this.timeframe,
      from: this.from,
      to: this.to,
      capital: this.capital,
      rule: this.state.activeRule$.value
    }).subscribe({
      next: (result) => {
        this.state.backtestResult$.next(result);
      },
      complete: () => {
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      }
    });
  }
}
