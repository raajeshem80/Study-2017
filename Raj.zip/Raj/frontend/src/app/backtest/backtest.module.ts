import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BacktestComponent } from './backtest.component';
import { MaterialModule } from '../shared/material.module';

@NgModule({
  declarations: [BacktestComponent],
  imports: [CommonModule, FormsModule, MaterialModule],
  exports: [BacktestComponent]
})
export class BacktestModule {}
