import { Component } from '@angular/core';
import { OrderApiService, OrderResponse } from '../core/services/order-api.service';
import { MarketStateService } from '../core/services/market-state.service';

@Component({
  selector: 'app-trade-plan',
  templateUrl: './trade-plan.component.html',
  styleUrls: ['./trade-plan.component.css']
})
export class TradePlanComponent {
  accountId = 'DEMO123';
  orderType: 'MARKET' | 'LIMIT' = 'MARKET';
  lastOrder?: OrderResponse;
  loading = false;

  constructor(
    public readonly state: MarketStateService,
    private readonly orderApiService: OrderApiService
  ) {}

  placeOrder(): void {
    const plan = this.state.tradePlan$.value;
    if (!plan) {
      return;
    }
    this.loading = true;
    this.orderApiService.place({
      broker: this.state.selectedBroker$.value,
      symbol: this.state.selectedSymbol$.value,
      accountId: this.accountId,
      side: plan.side,
      quantity: plan.quantity,
      orderType: this.orderType,
      price: this.orderType === 'LIMIT' ? plan.entry : undefined
    }).subscribe({
      next: (response) => {
        this.lastOrder = response;
      },
      complete: () => {
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      }
    });
  }

  cancelOrder(): void {
    if (!this.lastOrder) {
      return;
    }
    this.orderApiService.cancel(this.lastOrder.orderId, this.lastOrder.broker, this.lastOrder.accountId)
      .subscribe((response) => {
        this.lastOrder = response;
      });
  }
}
