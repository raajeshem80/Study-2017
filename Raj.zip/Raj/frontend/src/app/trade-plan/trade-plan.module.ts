import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TradePlanComponent } from './trade-plan.component';
import { MaterialModule } from '../shared/material.module';

@NgModule({
  declarations: [TradePlanComponent],
  imports: [CommonModule, FormsModule, MaterialModule],
  exports: [TradePlanComponent]
})
export class TradePlanModule {}
