import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription, interval, switchMap } from 'rxjs';
import { LiveApiService } from '../core/services/live-api.service';
import { MarketStateService } from '../core/services/market-state.service';
import { WsService } from '../core/services/ws.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy {
  broker = 'kite';
  symbol = 'RELIANCE';
  refreshing = false;
  private readonly subscriptions = new Subscription();

  constructor(
    public readonly state: MarketStateService,
    private readonly liveApiService: LiveApiService,
    private readonly wsService: WsService
  ) {}

  ngOnInit(): void {
    this.wsService.connect();
    this.refresh();
    this.subscriptions.add(
      interval(15000)
        .pipe(switchMap(() => this.liveApiService.analyze(this.broker, this.symbol)))
        .subscribe((analysis) => this.state.setAnalysis(analysis))
    );
    this.subscriptions.add(
      this.wsService.signal$.subscribe((signal) => {
        if (signal) {
          this.state.signal$.next(signal);
        }
      })
    );
    this.subscriptions.add(
      this.wsService.tradePlan$.subscribe((plan) => {
        if (plan) {
          this.state.tradePlan$.next(plan);
        }
      })
    );
  }

  refresh(): void {
    this.refreshing = true;
    this.state.selectBroker(this.broker);
    this.state.selectSymbol(this.symbol);
    this.liveApiService.analyze(this.broker, this.symbol).subscribe({
      next: (analysis) => {
        this.state.setAnalysis(analysis);
        this.wsService.subscribeForSymbol(this.broker, this.symbol);
      },
      complete: () => {
        this.refreshing = false;
      },
      error: () => {
        this.refreshing = false;
      }
    });
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
    this.wsService.disconnect();
  }
}
