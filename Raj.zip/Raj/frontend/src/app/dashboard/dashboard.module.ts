import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DashboardComponent } from './dashboard.component';
import { MaterialModule } from '../shared/material.module';
import { WatchlistModule } from '../watchlist/watchlist.module';
import { ChartModule } from '../chart/chart.module';
import { ScannerModule } from '../scanner/scanner.module';
import { SignalPanelModule } from '../signal-panel/signal-panel.module';
import { TradePlanModule } from '../trade-plan/trade-plan.module';
import { RuleBuilderModule } from '../rule-builder/rule-builder.module';
import { BacktestModule } from '../backtest/backtest.module';

@NgModule({
  declarations: [DashboardComponent],
  imports: [
    CommonModule,
    FormsModule,
    MaterialModule,
    WatchlistModule,
    ChartModule,
    ScannerModule,
    SignalPanelModule,
    TradePlanModule,
    RuleBuilderModule,
    BacktestModule
  ],
  exports: [DashboardComponent]
})
export class DashboardModule {}
