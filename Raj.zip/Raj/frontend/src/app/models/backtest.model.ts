import { RuleDsl } from './rule-dsl.model';

export interface BacktestRequest {
  broker: string;
  symbol: string;
  timeframe: string;
  from: string;
  to: string;
  capital: number;
  rule: RuleDsl;
}

export interface BacktestTrade {
  entryTime: string;
  exitTime: string;
  side: string;
  entry: number;
  exit: number;
  quantity: number;
  pnl: number;
}

export interface BacktestResult {
  broker: string;
  symbol: string;
  totalTrades: number;
  winRate: number;
  netPnl: number;
  maxDrawdown: number;
  expectancy: number;
  trades: BacktestTrade[];
}
