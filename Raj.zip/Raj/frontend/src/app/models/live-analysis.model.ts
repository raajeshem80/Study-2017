import { Signal } from './signal.model';
import { TradePlan } from './trade-plan.model';

export interface LiveAnalysisResponse {
  signal: Signal;
  tradePlan: TradePlan;
  indicators: {
    ema50: string;
    rsi14: string;
    vwap: string;
    atr14: string;
  };
  levels: {
    pivot: string;
    support: string;
    resistance: string;
    swingLow: string;
    swingHigh: string;
  };
}
