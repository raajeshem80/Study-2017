export type SignalAction = 'BUY' | 'SELL' | 'WAIT' | 'AVOID';

export interface Signal {
  broker: string;
  symbol: string;
  action: SignalAction;
  score: number;
  lastPrice: number;
  reasons: string[];
  timestamp: string;
}
