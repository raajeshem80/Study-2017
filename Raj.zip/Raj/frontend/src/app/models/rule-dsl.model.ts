export interface RuleCondition {
  field: string;
  comparator: string;
  value: string;
}

export interface RuleDsl {
  operator: 'AND' | 'OR';
  conditions: RuleCondition[];
  groups?: RuleDsl[];
}
