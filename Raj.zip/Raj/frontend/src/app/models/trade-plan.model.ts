export type OrderSide = 'BUY' | 'SELL';

export interface TradePlan {
  side: OrderSide;
  entry: number;
  stopLoss: number;
  target: number;
  quantity: number;
  riskReward: number;
}
