import { Component } from '@angular/core';
import { MarketStateService } from '../core/services/market-state.service';

@Component({
  selector: 'app-scanner',
  templateUrl: './scanner.component.html',
  styleUrls: ['./scanner.component.css']
})
export class ScannerComponent {
  constructor(public readonly state: MarketStateService) {}
}
