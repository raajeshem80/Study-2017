import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ScannerComponent } from './scanner.component';
import { MaterialModule } from '../shared/material.module';

@NgModule({
  declarations: [ScannerComponent],
  imports: [CommonModule, MaterialModule],
  exports: [ScannerComponent]
})
export class ScannerModule {}
