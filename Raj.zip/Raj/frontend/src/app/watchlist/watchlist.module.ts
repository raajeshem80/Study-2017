import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WatchlistComponent } from './watchlist.component';
import { MaterialModule } from '../shared/material.module';

@NgModule({
  declarations: [WatchlistComponent],
  imports: [CommonModule, MaterialModule],
  exports: [WatchlistComponent]
})
export class WatchlistModule {}
