# 📊 Trading Application — Technical Design Document (TDD)

## 1. Overview
This system is a **rule-based trading decision platform** integrating:
- Real-time broker data (Kite / Upstox)
- Multi-timeframe analysis (5m + 15m)
- Technical indicators (ATR, RSI, VWAP)
- Candlestick pattern detection
- Auto Support/Resistance detection
- Trade signal generation
- Risk management (ATR SL/TP + Position sizing)
- Backtesting engine
- WebSocket live streaming
- Angular dashboard UI

---

## 2. Tech Stack

### Backend
- Java 21
- Spring Boot 3.5.2
- Spring Web + WebFlux
- Spring Data JPA
- WebSocket (STOMP)
- H2 / PostgreSQL
- Redis (optional for caching)

### Frontend
- Angular 18 (NgModule-based, NOT standalone)
- Angular Material
- RxJS
- STOMP WebSocket client

---

## 3. High-Level Architecture

Angular UI
    ↓
Spring Boot API
    ├── Broker Layer (Kite / Upstox)
    ├── Symbol Mapping
    ├── Indicator Engine
    ├── Strategy Engine
    ├── Risk Engine
    ├── Backtesting Engine
    └── WebSocket Streaming

---

## 4. Core Modules

### 4.1 Broker Integration
- Supports:
  - Zerodha Kite API
  - Upstox API
- Handles:
  - Authentication
  - Quote fetching
  - WebSocket ticks

---

### 4.2 Symbol Mapping
Maps:
- UI → RELIANCE
- Kite → NSE:RELIANCE
- Upstox → NSE_EQ|INE002A01018

---

### 4.3 Market Data Module
- Fetch OHLC (5m, 15m)
- Maintain candle history

---

### 4.4 Indicator Engine

#### Indicators:
- EMA (50)
- RSI (14)
- VWAP
- ATR (14)

---

### 4.5 Support / Resistance

#### Methods:
- Pivot Points
- Swing High / Low

---

### 4.6 Candlestick Engine

Patterns:
- Bullish Engulfing
- Bearish Engulfing
- Hammer
- Doji

---

### 4.7 Strategy Engine

Combines:
- Trend (15m)
- Level (Support/Resistance)
- Pattern (5m)
- Confirmation (RSI + VWAP + Volume)

Output:
- Signal (BUY / SELL / WAIT / AVOID)
- Score

---

### 4.8 Risk Engine

#### ATR-based SL/TP:
- SL = Entry ± ATR * 1.5
- Target = Entry ± ATR * 3

#### Position Sizing:
- Risk = 1% capital
- Qty = Risk / (Entry - SL)

---

### 4.9 Backtesting Engine

Features:
- Historical simulation
- Win rate
- PnL
- Drawdown

---

### 4.10 WebSocket Streaming

- Live ticks → strategy evaluation
- Push signal to UI

---

## 5. API Design

### 5.1 Analyze Live
GET /api/live/{broker}/{symbol}

### 5.2 Backtest
POST /api/backtest

### 5.3 Rules
POST /api/rules/evaluate

---

## 6. Database Design

### Table: symbol_mapping
- symbol
- kite_symbol
- upstox_symbol

### Table: trades
- id
- symbol
- entry
- sl
- target
- pnl

---

## 7. Angular Modules

- AppModule
- DashboardModule
- ChartModule
- ScannerModule
- RuleBuilderModule
- TradePanelModule

---

## 8. UI Features

- Watchlist
- Chart (TradingView)
- Scanner
- Signal panel
- Rule builder
- Trade plan
- Backtest results

---

## 9. Non-Functional Requirements

- Low latency (<500ms)
- Fault-tolerant WebSocket
- Secure token storage
- Scalable microservice-ready

---

## 10. Future Enhancements

- AI-based signals
- Auto trading
- Portfolio analytics
- Alerts (Telegram)

---
