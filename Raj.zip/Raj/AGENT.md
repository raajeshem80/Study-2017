# 🧠 Codex Agent Instructions

You are an expert full-stack engineer.

## Goal
Generate a complete Trading Application using:
- Spring Boot 3.5.2 (Java 21)
- Angular 18 (NgModule, NOT standalone)

---

## Rules

1. Follow clean architecture:
   - Controller → Service → Engine → Repository

2. Modular design:
   - Broker Layer
   - Strategy Engine
   - Risk Engine
   - Indicator Engine

3. Angular must:
   - Use NgModules
   - Use Angular Material
   - Use services for API

4. Backend must:
   - Use DTOs
   - Use REST APIs
   - Include WebSocket

5. Include:
   - ATR SL/TP
   - RSI + VWAP
   - Multi-timeframe logic
   - Backtesting engine

6. Generate:
   - Full code
   - Proper folder structure
   - Sample data
   - Config files

7. Avoid:
   - Hardcoding values
   - Mixing concerns

---

## Output Format

- Backend folder structure
- Angular folder structure
- Key files with code
- Setup steps
