CREATE TABLE IF NOT EXISTS symbol_mapping (
    id BIGSERIAL PRIMARY KEY,
    symbol VARCHAR(40) NOT NULL UNIQUE,
    kite_symbol VARCHAR(80) NOT NULL,
    upstox_symbol VARCHAR(120) NOT NULL
);

CREATE TABLE IF NOT EXISTS candle_ohlcv (
    id BIGSERIAL PRIMARY KEY,
    broker VARCHAR(40) NOT NULL,
    symbol VARCHAR(40) NOT NULL,
    timeframe VARCHAR(10) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    open NUMERIC(18,4) NOT NULL,
    high NUMERIC(18,4) NOT NULL,
    low NUMERIC(18,4) NOT NULL,
    close NUMERIC(18,4) NOT NULL,
    volume NUMERIC(18,4) NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_candle_lookup ON candle_ohlcv (broker, symbol, timeframe, timestamp);

CREATE TABLE IF NOT EXISTS signal_event (
    id BIGSERIAL PRIMARY KEY,
    broker VARCHAR(40) NOT NULL,
    symbol VARCHAR(40) NOT NULL,
    action VARCHAR(20) NOT NULL,
    score INT NOT NULL,
    last_price NUMERIC(18,4) NOT NULL,
    reasons_json TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL
);

CREATE TABLE IF NOT EXISTS trade_execution (
    id BIGSERIAL PRIMARY KEY,
    order_id VARCHAR(80) NOT NULL UNIQUE,
    broker VARCHAR(40) NOT NULL,
    account_id VARCHAR(80) NOT NULL,
    symbol VARCHAR(40) NOT NULL,
    side VARCHAR(10) NOT NULL,
    quantity INT NOT NULL,
    price NUMERIC(18,4),
    status VARCHAR(20) NOT NULL,
    message_text TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL
);

CREATE TABLE IF NOT EXISTS backtest_run (
    id BIGSERIAL PRIMARY KEY,
    broker VARCHAR(40) NOT NULL,
    symbol VARCHAR(40) NOT NULL,
    timeframe VARCHAR(10) NOT NULL,
    from_time TIMESTAMP WITH TIME ZONE NOT NULL,
    to_time TIMESTAMP WITH TIME ZONE NOT NULL,
    win_rate NUMERIC(12,4) NOT NULL,
    net_pnl NUMERIC(18,4) NOT NULL,
    max_drawdown NUMERIC(18,4) NOT NULL,
    expectancy NUMERIC(18,4) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL
);

CREATE TABLE IF NOT EXISTS backtest_trade (
    id BIGSERIAL PRIMARY KEY,
    run_id BIGINT NOT NULL,
    symbol VARCHAR(40) NOT NULL,
    side VARCHAR(10) NOT NULL,
    entry NUMERIC(18,4) NOT NULL,
    exit NUMERIC(18,4) NOT NULL,
    quantity INT NOT NULL,
    pnl NUMERIC(18,4) NOT NULL,
    entry_time TIMESTAMP WITH TIME ZONE NOT NULL,
    exit_time TIMESTAMP WITH TIME ZONE NOT NULL
);

INSERT INTO symbol_mapping (symbol, kite_symbol, upstox_symbol) VALUES
('RELIANCE', 'NSE:RELIANCE', 'NSE_EQ|INE002A01018'),
('TCS', 'NSE:TCS', 'NSE_EQ|INE467B01029'),
('INFY', 'NSE:INFY', 'NSE_EQ|INE009A01021')
ON CONFLICT (symbol) DO NOTHING;
