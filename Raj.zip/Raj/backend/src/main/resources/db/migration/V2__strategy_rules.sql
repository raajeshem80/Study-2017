CREATE TABLE IF NOT EXISTS strategy_rule_set (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    symbol VARCHAR(40) NOT NULL,
    dsl_json TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_rule_symbol_active ON strategy_rule_set (symbol, is_active, updated_at DESC);

CREATE TABLE IF NOT EXISTS broker_credentials (
    id BIGSERIAL PRIMARY KEY,
    broker VARCHAR(40) NOT NULL,
    account_id VARCHAR(80) NOT NULL,
    api_key VARCHAR(200) NOT NULL,
    encrypted_access_token TEXT NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    CONSTRAINT uq_broker_account UNIQUE (broker, account_id)
);
