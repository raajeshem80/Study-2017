CREATE TABLE IF NOT EXISTS app_setting (
    id BIGSERIAL PRIMARY KEY,
    setting_key VARCHAR(160) NOT NULL UNIQUE,
    setting_value TEXT NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL
);

INSERT INTO app_setting (setting_key, setting_value, updated_at) VALUES
('order.kill_switch', 'false', NOW()),
('order.dry_run', 'true', NOW()),
('order.api_key', 'change-me', NOW()),
('order.ip_allowlist', '[\"127.0.0.1\",\"::1\"]', NOW()),
('order.account_allowlist', '[\"DEMO123\"]', NOW())
ON CONFLICT (setting_key) DO NOTHING;
