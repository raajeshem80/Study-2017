package com.tradingapp.api;

import com.tradingapp.api.dto.LiveAnalysisResponse;
import com.tradingapp.strategy.LiveAnalysisService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/live")
public class LiveAnalysisController {

    private final LiveAnalysisService liveAnalysisService;

    public LiveAnalysisController(LiveAnalysisService liveAnalysisService) {
        this.liveAnalysisService = liveAnalysisService;
    }

    @GetMapping("/{broker}/{symbol}")
    public LiveAnalysisResponse analyze(@PathVariable String broker, @PathVariable String symbol) {
        return liveAnalysisService.analyze(broker, symbol);
    }
}
