package com.tradingapp.backtest.dto;

import java.math.BigDecimal;
import java.time.Instant;

public record BacktestTradeResult(
        Instant entryTime,
        Instant exitTime,
        String side,
        BigDecimal entry,
        BigDecimal exit,
        int quantity,
        BigDecimal pnl
) {
}
