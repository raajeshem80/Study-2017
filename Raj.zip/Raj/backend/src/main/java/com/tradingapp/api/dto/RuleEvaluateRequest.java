package com.tradingapp.api.dto;

import com.tradingapp.strategy.dto.RuleDslDto;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.Map;

public record RuleEvaluateRequest(
        @NotBlank String name,
        @NotBlank String symbol,
        @Valid RuleDslDto rule,
        @NotEmpty Map<String, Object> context
) {
}
