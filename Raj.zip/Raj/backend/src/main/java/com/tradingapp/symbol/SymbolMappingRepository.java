package com.tradingapp.symbol;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SymbolMappingRepository extends JpaRepository<SymbolMappingEntity, Long> {
    Optional<SymbolMappingEntity> findBySymbolIgnoreCase(String symbol);
}
