package com.tradingapp.websocket;

import com.tradingapp.websocket.dto.OrderWsMessage;
import com.tradingapp.websocket.dto.SignalWsMessage;
import com.tradingapp.websocket.dto.TickWsMessage;
import com.tradingapp.websocket.dto.TradePlanWsMessage;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

@Component
public class MarketStreamPublisher {

    private final SimpMessagingTemplate messagingTemplate;

    public MarketStreamPublisher(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    public void publishTick(String symbol, TickWsMessage message) {
        messagingTemplate.convertAndSend("/topic/ticks." + symbol, message);
    }

    public void publishSignal(String symbol, SignalWsMessage message) {
        messagingTemplate.convertAndSend("/topic/signals." + symbol, message);
    }

    public void publishTradePlan(String symbol, TradePlanWsMessage message) {
        messagingTemplate.convertAndSend("/topic/tradeplan." + symbol, message);
    }

    public void publishOrder(String accountId, OrderWsMessage message) {
        messagingTemplate.convertAndSend("/topic/orders." + accountId, message);
    }
}
