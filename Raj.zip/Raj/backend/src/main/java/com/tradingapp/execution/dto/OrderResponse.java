package com.tradingapp.execution.dto;

import com.tradingapp.broker.api.OrderStatus;
import java.time.Instant;

public record OrderResponse(
        String orderId,
        String broker,
        String accountId,
        OrderStatus status,
        String message,
        Instant timestamp
) {
}
