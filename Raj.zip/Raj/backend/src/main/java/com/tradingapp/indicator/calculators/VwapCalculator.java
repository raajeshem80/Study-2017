package com.tradingapp.indicator.calculators;

import com.tradingapp.broker.api.CandleData;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

public class VwapCalculator {

    public BigDecimal calculate(List<CandleData> candles) {
        if (candles == null || candles.isEmpty()) {
            return BigDecimal.ZERO;
        }
        double pvSum = 0.0;
        double volumeSum = 0.0;
        for (CandleData candle : candles) {
            double typicalPrice = (candle.high().doubleValue() + candle.low().doubleValue() + candle.close().doubleValue()) / 3.0;
            double volume = candle.volume().doubleValue();
            pvSum += typicalPrice * volume;
            volumeSum += volume;
        }
        if (volumeSum == 0.0) {
            return BigDecimal.ZERO;
        }
        return BigDecimal.valueOf(pvSum / volumeSum).setScale(4, RoundingMode.HALF_UP);
    }
}
