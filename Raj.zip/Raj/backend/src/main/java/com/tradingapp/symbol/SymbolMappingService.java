package com.tradingapp.symbol;

import com.tradingapp.broker.api.BrokerName;
import org.springframework.stereotype.Service;

@Service
public class SymbolMappingService {

    private final SymbolMappingRepository symbolMappingRepository;

    public SymbolMappingService(SymbolMappingRepository symbolMappingRepository) {
        this.symbolMappingRepository = symbolMappingRepository;
    }

    public String resolveBrokerSymbol(BrokerName brokerName, String uiSymbol) {
        SymbolMappingEntity entity = symbolMappingRepository.findBySymbolIgnoreCase(uiSymbol)
                .orElseThrow(() -> new IllegalArgumentException("Symbol mapping not found for " + uiSymbol));
        return switch (brokerName) {
            case KITE -> entity.getKiteSymbol();
            case UPSTOX -> entity.getUpstoxSymbol();
            case MOCK -> entity.getKiteSymbol();
        };
    }

    public SymbolMappingEntity getByUiSymbol(String uiSymbol) {
        return symbolMappingRepository.findBySymbolIgnoreCase(uiSymbol)
                .orElseThrow(() -> new IllegalArgumentException("Symbol mapping not found for " + uiSymbol));
    }
}
