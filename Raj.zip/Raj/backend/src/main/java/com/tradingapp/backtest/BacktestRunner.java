package com.tradingapp.backtest;

import com.tradingapp.backtest.dto.BacktestResult;
import com.tradingapp.backtest.dto.BacktestTradeResult;
import com.tradingapp.broker.api.CandleData;
import com.tradingapp.broker.api.OrderSide;
import com.tradingapp.risk.RiskEngineService;
import com.tradingapp.risk.dto.TradePlanDto;
import com.tradingapp.strategy.StrategyEngineService;
import com.tradingapp.strategy.dto.SignalAction;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class BacktestRunner {

    private final StrategyEngineService strategyEngineService;
    private final RiskEngineService riskEngineService;

    public BacktestRunner(StrategyEngineService strategyEngineService, RiskEngineService riskEngineService) {
        this.strategyEngineService = strategyEngineService;
        this.riskEngineService = riskEngineService;
    }

    public BacktestResult run(String broker, String symbol, BigDecimal capital, List<CandleData> candles5m, List<CandleData> candles15m) {
        if (candles5m == null || candles15m == null || candles5m.size() < 3 || candles15m.isEmpty()) {
            return new BacktestResult(
                    broker,
                    symbol,
                    0,
                    BigDecimal.ZERO,
                    BigDecimal.ZERO,
                    BigDecimal.ZERO,
                    BigDecimal.ZERO,
                    List.of()
            );
        }

        List<BacktestTradeResult> trades = new ArrayList<>();
        BigDecimal pnlSum = BigDecimal.ZERO;
        BigDecimal equity = capital;
        BigDecimal peak = capital;
        BigDecimal maxDrawdown = BigDecimal.ZERO;
        int wins = 0;

        int startIndex = Math.min(60, candles5m.size() - 2);
        for (int i = startIndex; i < candles5m.size() - 1; i++) {
            List<CandleData> s5 = candles5m.subList(Math.max(0, i - 80), i + 1);
            List<CandleData> s15 = candles15m.subList(Math.max(0, Math.min(candles15m.size() - 1, i / 3) - 80), Math.min(candles15m.size(), (i / 3) + 1));
            if (s15.isEmpty()) {
                continue;
            }

            StrategyEngineService.StrategyBundle bundle = strategyEngineService.evaluate(broker, symbol, s5, s15);
            SignalAction action = bundle.signal().action();
            if (action != SignalAction.BUY && action != SignalAction.SELL) {
                continue;
            }

            CandleData entryCandle = candles5m.get(i);
            CandleData exitCandle = candles5m.get(i + 1);

            OrderSide side = action == SignalAction.BUY ? OrderSide.BUY : OrderSide.SELL;
            TradePlanDto plan = riskEngineService.buildPlan(side, equity, entryCandle.close(), bundle.context().atr());

            BigDecimal pnl = side == OrderSide.BUY
                    ? exitCandle.close().subtract(plan.entry()).multiply(BigDecimal.valueOf(plan.quantity()))
                    : plan.entry().subtract(exitCandle.close()).multiply(BigDecimal.valueOf(plan.quantity()));

            pnl = pnl.setScale(4, RoundingMode.HALF_UP);
            pnlSum = pnlSum.add(pnl);
            equity = equity.add(pnl);
            if (equity.compareTo(peak) > 0) {
                peak = equity;
            }
            BigDecimal drawdown = peak.subtract(equity);
            if (drawdown.compareTo(maxDrawdown) > 0) {
                maxDrawdown = drawdown;
            }
            if (pnl.compareTo(BigDecimal.ZERO) > 0) {
                wins++;
            }

            trades.add(new BacktestTradeResult(
                    entryCandle.timestamp(),
                    exitCandle.timestamp(),
                    side.name(),
                    plan.entry(),
                    exitCandle.close(),
                    plan.quantity(),
                    pnl
            ));
        }

        int total = trades.size();
        BigDecimal winRate = total == 0 ? BigDecimal.ZERO
                : BigDecimal.valueOf((wins * 100.0) / total).setScale(4, RoundingMode.HALF_UP);
        BigDecimal expectancy = total == 0 ? BigDecimal.ZERO : pnlSum.divide(BigDecimal.valueOf(total), 4, RoundingMode.HALF_UP);

        return new BacktestResult(
                broker,
                symbol,
                total,
                winRate,
                pnlSum,
                maxDrawdown,
                expectancy,
                trades
        );
    }
}
