package com.tradingapp.persistence.repositories;

import com.tradingapp.persistence.entities.SignalEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SignalRepository extends JpaRepository<SignalEntity, Long> {
    Optional<SignalEntity> findTopByBrokerAndSymbolOrderByCreatedAtDesc(String broker, String symbol);
}
