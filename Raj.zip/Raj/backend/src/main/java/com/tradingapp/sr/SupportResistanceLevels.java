package com.tradingapp.sr;

import java.math.BigDecimal;

public record SupportResistanceLevels(
        BigDecimal pivot,
        BigDecimal support,
        BigDecimal resistance,
        BigDecimal swingLow,
        BigDecimal swingHigh
) {
}
