package com.tradingapp.strategy;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tradingapp.api.dto.LiveAnalysisResponse;
import com.tradingapp.broker.api.BrokerClient;
import com.tradingapp.broker.api.BrokerName;
import com.tradingapp.broker.api.OrderSide;
import com.tradingapp.broker.api.QuoteData;
import com.tradingapp.broker.routing.BrokerRouter;
import com.tradingapp.marketdata.CandleIngestionService;
import com.tradingapp.persistence.entities.SignalEntity;
import com.tradingapp.persistence.repositories.SignalRepository;
import com.tradingapp.risk.RiskEngineService;
import com.tradingapp.risk.dto.TradePlanDto;
import com.tradingapp.strategy.dto.SignalAction;
import com.tradingapp.strategy.dto.SignalDto;
import com.tradingapp.symbol.SymbolMappingService;
import com.tradingapp.websocket.MarketStreamPublisher;
import com.tradingapp.websocket.dto.SignalWsMessage;
import com.tradingapp.websocket.dto.TickWsMessage;
import com.tradingapp.websocket.dto.TradePlanWsMessage;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class LiveAnalysisService {

    private final BrokerRouter brokerRouter;
    private final SymbolMappingService symbolMappingService;
    private final StrategyEngineService strategyEngineService;
    private final RiskEngineService riskEngineService;
    private final CandleIngestionService candleIngestionService;
    private final SignalRepository signalRepository;
    private final ObjectMapper objectMapper;
    private final MarketStreamPublisher marketStreamPublisher;

    public LiveAnalysisService(
            BrokerRouter brokerRouter,
            SymbolMappingService symbolMappingService,
            StrategyEngineService strategyEngineService,
            RiskEngineService riskEngineService,
            CandleIngestionService candleIngestionService,
            SignalRepository signalRepository,
            ObjectMapper objectMapper,
            MarketStreamPublisher marketStreamPublisher
    ) {
        this.brokerRouter = brokerRouter;
        this.symbolMappingService = symbolMappingService;
        this.strategyEngineService = strategyEngineService;
        this.riskEngineService = riskEngineService;
        this.candleIngestionService = candleIngestionService;
        this.signalRepository = signalRepository;
        this.objectMapper = objectMapper;
        this.marketStreamPublisher = marketStreamPublisher;
    }

    @Transactional
    public LiveAnalysisResponse analyze(String broker, String symbol) {
        BrokerClient brokerClient = brokerRouter.route(broker);
        BrokerName brokerName = brokerClient.brokerName();
        String brokerSymbol = symbolMappingService.resolveBrokerSymbol(brokerName, symbol);

        Instant to = Instant.now();
        Instant from = to.minus(Duration.ofDays(5));

        QuoteData quote = brokerClient.fetchQuote(brokerSymbol);
        List<com.tradingapp.broker.api.CandleData> candles5m = brokerClient.fetchHistoricalCandles(brokerSymbol, "5m", from, to);
        List<com.tradingapp.broker.api.CandleData> candles15m = brokerClient.fetchHistoricalCandles(brokerSymbol, "15m", from, to);

        candleIngestionService.storeCandles(brokerName, symbol, candles5m);
        candleIngestionService.storeCandles(brokerName, symbol, candles15m);

        StrategyEngineService.StrategyBundle bundle = strategyEngineService.evaluate(broker, symbol, candles5m, candles15m);
        SignalDto signal = bundle.signal();
        OrderSide side = signal.action() == SignalAction.SELL ? OrderSide.SELL : OrderSide.BUY;
        TradePlanDto tradePlan = riskEngineService.buildPlan(side, BigDecimal.valueOf(100_000), quote.lastPrice(), bundle.context().atr());

        persistSignal(signal);
        publishStreams(symbol, broker, quote, signal, tradePlan);

        return new LiveAnalysisResponse(
                signal,
                tradePlan,
                new LiveAnalysisResponse.IndicatorView(
                        bundle.indicators5m().ema50().toPlainString(),
                        bundle.indicators5m().rsi14().toPlainString(),
                        bundle.indicators5m().vwap().toPlainString(),
                        bundle.indicators5m().atr14().toPlainString()
                ),
                new LiveAnalysisResponse.LevelView(
                        bundle.levels().pivot().toPlainString(),
                        bundle.levels().support().toPlainString(),
                        bundle.levels().resistance().toPlainString(),
                        bundle.levels().swingLow().toPlainString(),
                        bundle.levels().swingHigh().toPlainString()
                )
        );
    }

    private void persistSignal(SignalDto signal) {
        SignalEntity entity = new SignalEntity();
        entity.setBroker(signal.broker());
        entity.setSymbol(signal.symbol());
        entity.setAction(signal.action().name());
        entity.setScore(signal.score());
        entity.setLastPrice(signal.lastPrice());
        entity.setReasonsJson(writeJson(signal.reasons()));
        entity.setCreatedAt(Instant.now());
        signalRepository.save(entity);
    }

    private String writeJson(Object payload) {
        try {
            return objectMapper.writeValueAsString(payload);
        } catch (JsonProcessingException ex) {
            throw new IllegalArgumentException("Failed to serialize signal payload", ex);
        }
    }

    private void publishStreams(String symbol, String broker, QuoteData quote, SignalDto signal, TradePlanDto tradePlan) {
        marketStreamPublisher.publishTick(symbol, new TickWsMessage(
                "v1",
                broker,
                symbol,
                quote.lastPrice(),
                quote.volume(),
                quote.timestamp()
        ));
        marketStreamPublisher.publishSignal(symbol, new SignalWsMessage(
                "v1",
                broker,
                symbol,
                signal.action(),
                signal.score(),
                signal.lastPrice(),
                signal.reasons(),
                signal.timestamp()
        ));
        marketStreamPublisher.publishTradePlan(symbol, new TradePlanWsMessage(
                "v1",
                broker,
                symbol,
                tradePlan.side(),
                tradePlan.entry(),
                tradePlan.stopLoss(),
                tradePlan.target(),
                tradePlan.quantity(),
                tradePlan.riskReward(),
                Instant.now()
        ));
    }
}
