package com.tradingapp.indicator.calculators;

import com.tradingapp.broker.api.CandleData;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

public class AtrCalculator {

    public BigDecimal calculate(List<CandleData> candles, int period) {
        if (candles == null || candles.size() <= period) {
            return BigDecimal.ZERO;
        }

        List<Double> trValues = new ArrayList<>();
        for (int i = 1; i < candles.size(); i++) {
            CandleData current = candles.get(i);
            CandleData previous = candles.get(i - 1);
            double highLow = current.high().subtract(current.low()).doubleValue();
            double highClose = Math.abs(current.high().doubleValue() - previous.close().doubleValue());
            double lowClose = Math.abs(current.low().doubleValue() - previous.close().doubleValue());
            trValues.add(Math.max(highLow, Math.max(highClose, lowClose)));
        }

        if (trValues.size() < period) {
            return BigDecimal.ZERO;
        }

        double atr = trValues.subList(0, period).stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
        for (int i = period; i < trValues.size(); i++) {
            atr = ((atr * (period - 1)) + trValues.get(i)) / period;
        }
        return BigDecimal.valueOf(atr).setScale(4, RoundingMode.HALF_UP);
    }
}
