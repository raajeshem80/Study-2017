package com.tradingapp.broker.mock;

import com.tradingapp.broker.api.BrokerClient;
import com.tradingapp.broker.api.BrokerName;
import com.tradingapp.broker.api.CandleData;
import com.tradingapp.broker.api.OrderSnapshot;
import com.tradingapp.broker.api.OrderStatus;
import com.tradingapp.broker.api.PlaceOrderCommand;
import com.tradingapp.broker.api.QuoteData;
import com.tradingapp.broker.api.TickData;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;

@Component
@Primary
public class MockBrokerClient implements BrokerClient {

    @Override
    public BrokerName brokerName() {
        return BrokerName.MOCK;
    }

    @Override
    public QuoteData fetchQuote(String brokerSymbol) {
        BigDecimal base = randomPrice();
        return new QuoteData(
                brokerSymbol,
                base,
                base.add(BigDecimal.valueOf(14)),
                base.subtract(BigDecimal.valueOf(16)),
                BigDecimal.valueOf(200_000 + ThreadLocalRandom.current().nextInt(400_000)),
                Instant.now()
        );
    }

    @Override
    public List<CandleData> fetchHistoricalCandles(String brokerSymbol, String timeframe, Instant from, Instant to) {
        long step = "15m".equalsIgnoreCase(timeframe) ? 15 : 5;
        List<CandleData> candles = new ArrayList<>();
        Instant cursor = from;
        BigDecimal price = randomPrice();

        while (!cursor.isAfter(to)) {
            BigDecimal open = price;
            BigDecimal delta = BigDecimal.valueOf(ThreadLocalRandom.current().nextDouble(-7.5, 7.5));
            BigDecimal close = open.add(delta).max(BigDecimal.ONE);
            BigDecimal high = open.max(close).add(BigDecimal.valueOf(ThreadLocalRandom.current().nextDouble(0.1, 3.5)));
            BigDecimal low = open.min(close).subtract(BigDecimal.valueOf(ThreadLocalRandom.current().nextDouble(0.1, 3.5))).max(BigDecimal.ZERO);
            BigDecimal volume = BigDecimal.valueOf(ThreadLocalRandom.current().nextLong(30_000, 400_000));

            candles.add(new CandleData(cursor, scale(open), scale(high), scale(low), scale(close), volume, timeframe));
            price = close;
            cursor = cursor.plus(Duration.ofMinutes(step));
        }
        return candles;
    }

    @Override
    public String placeOrder(PlaceOrderCommand command) {
        return "MOCK-" + UUID.randomUUID().toString().substring(0, 12).toUpperCase();
    }

    @Override
    public void cancelOrder(String orderId, String accountId) {
        // No-op for mock broker.
    }

    @Override
    public OrderSnapshot getOrder(String orderId, String accountId) {
        return new OrderSnapshot(
                orderId,
                accountId,
                "MOCK:SYMBOL",
                OrderStatus.FILLED,
                com.tradingapp.broker.api.OrderSide.BUY,
                10,
                scale(randomPrice()),
                Instant.now(),
                "Mock order status"
        );
    }

    @Override
    public Flux<TickData> subscribeTicks(List<String> brokerSymbols) {
        List<String> symbols = brokerSymbols == null || brokerSymbols.isEmpty()
                ? List.of("MOCK:RELIANCE")
                : brokerSymbols;
        return Flux.interval(Duration.ofSeconds(1))
                .map(i -> {
                    String symbol = symbols.get((int) (i % symbols.size()));
                    return new TickData(symbol, scale(randomPrice()), BigDecimal.valueOf(ThreadLocalRandom.current().nextLong(1_000, 10_000)), Instant.now());
                });
    }

    private BigDecimal randomPrice() {
        return BigDecimal.valueOf(ThreadLocalRandom.current().nextDouble(120.0, 3100.0));
    }

    private BigDecimal scale(BigDecimal value) {
        return value.setScale(2, RoundingMode.HALF_UP);
    }
}
