package com.tradingapp.broker.api;

import java.math.BigDecimal;
import java.time.Instant;

public record OrderSnapshot(
        String orderId,
        String accountId,
        String brokerSymbol,
        OrderStatus status,
        OrderSide side,
        int quantity,
        BigDecimal averagePrice,
        Instant updatedAt,
        String message
) {
}
