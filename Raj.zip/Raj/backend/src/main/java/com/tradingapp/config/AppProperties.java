package com.tradingapp.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app")
public class AppProperties {

    private final Broker broker = new Broker();
    private final OrderGuard orderGuard = new OrderGuard();
    private final Backtest backtest = new Backtest();
    private final Crypto crypto = new Crypto();

    public Broker getBroker() {
        return broker;
    }

    public OrderGuard getOrderGuard() {
        return orderGuard;
    }

    public Backtest getBacktest() {
        return backtest;
    }

    public Crypto getCrypto() {
        return crypto;
    }

    public static final class Broker {
        private boolean mockMode = true;
        private final Provider kite = new Provider();
        private final Provider upstox = new Provider();

        public boolean isMockMode() {
            return mockMode;
        }

        public void setMockMode(boolean mockMode) {
            this.mockMode = mockMode;
        }

        public Provider getKite() {
            return kite;
        }

        public Provider getUpstox() {
            return upstox;
        }
    }

    public static final class Provider {
        private String baseUrl;
        private String wsUrl;
        private String apiKey;
        private String apiSecret;
        private String accessToken;
        private String accountId;

        public String getBaseUrl() {
            return baseUrl;
        }

        public void setBaseUrl(String baseUrl) {
            this.baseUrl = baseUrl;
        }

        public String getWsUrl() {
            return wsUrl;
        }

        public void setWsUrl(String wsUrl) {
            this.wsUrl = wsUrl;
        }

        public String getApiKey() {
            return apiKey;
        }

        public void setApiKey(String apiKey) {
            this.apiKey = apiKey;
        }

        public String getApiSecret() {
            return apiSecret;
        }

        public void setApiSecret(String apiSecret) {
            this.apiSecret = apiSecret;
        }

        public String getAccessToken() {
            return accessToken;
        }

        public void setAccessToken(String accessToken) {
            this.accessToken = accessToken;
        }

        public String getAccountId() {
            return accountId;
        }

        public void setAccountId(String accountId) {
            this.accountId = accountId;
        }
    }

    public static final class OrderGuard {
        private boolean killSwitch = false;
        private boolean dryRun = true;
        private String apiKey = "change-me";
        private List<String> ipAllowlist = new ArrayList<>();
        private List<String> accountAllowlist = new ArrayList<>();

        public boolean isKillSwitch() {
            return killSwitch;
        }

        public void setKillSwitch(boolean killSwitch) {
            this.killSwitch = killSwitch;
        }

        public boolean isDryRun() {
            return dryRun;
        }

        public void setDryRun(boolean dryRun) {
            this.dryRun = dryRun;
        }

        public String getApiKey() {
            return apiKey;
        }

        public void setApiKey(String apiKey) {
            this.apiKey = apiKey;
        }

        public List<String> getIpAllowlist() {
            return ipAllowlist;
        }

        public void setIpAllowlist(List<String> ipAllowlist) {
            this.ipAllowlist = ipAllowlist;
        }

        public List<String> getAccountAllowlist() {
            return accountAllowlist;
        }

        public void setAccountAllowlist(List<String> accountAllowlist) {
            this.accountAllowlist = accountAllowlist;
        }
    }

    public static final class Backtest {
        private int maxCandles = 3_000;

        public int getMaxCandles() {
            return maxCandles;
        }

        public void setMaxCandles(int maxCandles) {
            this.maxCandles = maxCandles;
        }
    }

    public static final class Crypto {
        private String key = "0123456789abcdef0123456789abcdef";

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }
    }
}
