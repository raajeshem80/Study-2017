package com.tradingapp.persistence.repositories;

import com.tradingapp.persistence.entities.BrokerCredentialEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BrokerCredentialRepository extends JpaRepository<BrokerCredentialEntity, Long> {
    Optional<BrokerCredentialEntity> findByBrokerAndAccountId(String broker, String accountId);
}
