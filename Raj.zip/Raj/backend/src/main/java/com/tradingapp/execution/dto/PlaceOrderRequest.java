package com.tradingapp.execution.dto;

import com.tradingapp.broker.api.OrderSide;
import com.tradingapp.broker.api.OrderType;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

public record PlaceOrderRequest(
        @NotBlank String broker,
        @NotBlank String symbol,
        @NotBlank String accountId,
        @NotNull OrderSide side,
        @Min(1) int quantity,
        @NotNull OrderType orderType,
        BigDecimal price
) {
}
