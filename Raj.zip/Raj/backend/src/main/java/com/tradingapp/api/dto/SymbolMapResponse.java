package com.tradingapp.api.dto;

public record SymbolMapResponse(
        String symbol,
        String kiteSymbol,
        String upstoxSymbol
) {
}
