package com.tradingapp.execution;

public record OrderGuardContext(
        String apiKey,
        String clientIp,
        String accountId
) {
}
