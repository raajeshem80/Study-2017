package com.tradingapp.candlepattern;

import com.tradingapp.broker.api.CandleData;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class CandlestickPatternService {

    public CandlestickPattern detect(List<CandleData> candles) {
        if (candles == null || candles.size() < 2) {
            return CandlestickPattern.NONE;
        }
        CandleData last = candles.getLast();
        CandleData prev = candles.get(candles.size() - 2);

        if (isBullishEngulfing(prev, last)) {
            return CandlestickPattern.BULLISH_ENGULFING;
        }
        if (isBearishEngulfing(prev, last)) {
            return CandlestickPattern.BEARISH_ENGULFING;
        }
        if (isHammer(last)) {
            return CandlestickPattern.HAMMER;
        }
        if (isDoji(last)) {
            return CandlestickPattern.DOJI;
        }
        return CandlestickPattern.NONE;
    }

    private boolean isBullishEngulfing(CandleData prev, CandleData last) {
        return prev.close().compareTo(prev.open()) < 0
                && last.close().compareTo(last.open()) > 0
                && last.open().compareTo(prev.close()) <= 0
                && last.close().compareTo(prev.open()) >= 0;
    }

    private boolean isBearishEngulfing(CandleData prev, CandleData last) {
        return prev.close().compareTo(prev.open()) > 0
                && last.close().compareTo(last.open()) < 0
                && last.open().compareTo(prev.close()) >= 0
                && last.close().compareTo(prev.open()) <= 0;
    }

    private boolean isHammer(CandleData candle) {
        BigDecimal body = candle.close().subtract(candle.open()).abs();
        BigDecimal lowerWick = candle.open().min(candle.close()).subtract(candle.low()).abs();
        BigDecimal upperWick = candle.high().subtract(candle.open().max(candle.close())).abs();
        return lowerWick.compareTo(body.multiply(BigDecimal.valueOf(2))) >= 0
                && upperWick.compareTo(body) <= 0;
    }

    private boolean isDoji(CandleData candle) {
        BigDecimal totalRange = candle.high().subtract(candle.low()).abs();
        if (totalRange.compareTo(BigDecimal.ZERO) == 0) {
            return false;
        }
        BigDecimal body = candle.close().subtract(candle.open()).abs();
        return body.divide(totalRange, 8, java.math.RoundingMode.HALF_UP).compareTo(BigDecimal.valueOf(0.1)) <= 0;
    }
}
