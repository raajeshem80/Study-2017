package com.tradingapp.persistence.repositories;

import com.tradingapp.persistence.entities.TradeEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TradeRepository extends JpaRepository<TradeEntity, Long> {
    Optional<TradeEntity> findByOrderId(String orderId);
}
