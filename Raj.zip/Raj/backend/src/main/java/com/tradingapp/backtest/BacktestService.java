package com.tradingapp.backtest;

import com.tradingapp.backtest.dto.BacktestRequest;
import com.tradingapp.backtest.dto.BacktestResult;
import com.tradingapp.broker.api.BrokerClient;
import com.tradingapp.broker.api.BrokerName;
import com.tradingapp.broker.api.CandleData;
import com.tradingapp.broker.routing.BrokerRouter;
import com.tradingapp.persistence.entities.BacktestRunEntity;
import com.tradingapp.persistence.entities.BacktestTradeEntity;
import com.tradingapp.persistence.repositories.BacktestRunRepository;
import com.tradingapp.persistence.repositories.BacktestTradeRepository;
import com.tradingapp.symbol.SymbolMappingService;
import java.time.Duration;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BacktestService {

    private final BrokerRouter brokerRouter;
    private final SymbolMappingService symbolMappingService;
    private final BacktestRunner backtestRunner;
    private final BacktestRunRepository backtestRunRepository;
    private final BacktestTradeRepository backtestTradeRepository;

    public BacktestService(
            BrokerRouter brokerRouter,
            SymbolMappingService symbolMappingService,
            BacktestRunner backtestRunner,
            BacktestRunRepository backtestRunRepository,
            BacktestTradeRepository backtestTradeRepository
    ) {
        this.brokerRouter = brokerRouter;
        this.symbolMappingService = symbolMappingService;
        this.backtestRunner = backtestRunner;
        this.backtestRunRepository = backtestRunRepository;
        this.backtestTradeRepository = backtestTradeRepository;
    }

    @Transactional
    public BacktestResult run(BacktestRequest request) {
        BrokerClient brokerClient = brokerRouter.route(request.broker());
        BrokerName brokerName = brokerClient.brokerName();
        String brokerSymbol = symbolMappingService.resolveBrokerSymbol(brokerName, request.symbol());

        List<CandleData> candles5m = brokerClient.fetchHistoricalCandles(brokerSymbol, "5m", request.from(), request.to());
        List<CandleData> candles15m = brokerClient.fetchHistoricalCandles(
                brokerSymbol,
                "15m",
                request.from(),
                request.to().plus(Duration.ofMinutes(15))
        );

        BacktestResult result = backtestRunner.run(request.broker(), request.symbol(), request.capital(), candles5m, candles15m);
        persistRun(request, result);
        return result;
    }

    private void persistRun(BacktestRequest request, BacktestResult result) {
        BacktestRunEntity run = new BacktestRunEntity();
        run.setBroker(request.broker());
        run.setSymbol(request.symbol());
        run.setTimeframe(request.timeframe());
        run.setFromTime(request.from());
        run.setToTime(request.to());
        run.setWinRate(result.winRate());
        run.setNetPnl(result.netPnl());
        run.setMaxDrawdown(result.maxDrawdown());
        run.setExpectancy(result.expectancy());
        BacktestRunEntity savedRun = backtestRunRepository.save(run);

        List<BacktestTradeEntity> trades = result.trades().stream().map(t -> {
            BacktestTradeEntity entity = new BacktestTradeEntity();
            entity.setRunId(savedRun.getId());
            entity.setSymbol(request.symbol());
            entity.setSide(t.side());
            entity.setEntry(t.entry());
            entity.setExit(t.exit());
            entity.setQuantity(t.quantity());
            entity.setPnl(t.pnl());
            entity.setEntryTime(t.entryTime());
            entity.setExitTime(t.exitTime());
            return entity;
        }).toList();
        backtestTradeRepository.saveAll(trades);
    }
}
