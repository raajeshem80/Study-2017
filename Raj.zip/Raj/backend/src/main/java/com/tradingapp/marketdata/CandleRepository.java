package com.tradingapp.marketdata;

import java.time.Instant;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CandleRepository extends JpaRepository<CandleEntity, Long> {

    List<CandleEntity> findTop300ByBrokerAndSymbolAndTimeframeAndTimestampBetweenOrderByTimestampAsc(
            String broker,
            String symbol,
            String timeframe,
            Instant from,
            Instant to
    );
}
