package com.tradingapp.risk;

import com.tradingapp.broker.api.OrderSide;
import com.tradingapp.risk.dto.TradePlanDto;
import java.math.BigDecimal;
import java.math.RoundingMode;
import org.springframework.stereotype.Service;

@Service
public class RiskEngineService {

    public TradePlanDto buildPlan(OrderSide side, BigDecimal capital, BigDecimal entry, BigDecimal atr) {
        if (atr == null || atr.compareTo(BigDecimal.ZERO) <= 0) {
            atr = BigDecimal.valueOf(1.0);
        }

        BigDecimal slDelta = atr.multiply(BigDecimal.valueOf(1.5));
        BigDecimal tpDelta = atr.multiply(BigDecimal.valueOf(3.0));

        BigDecimal stopLoss = side == OrderSide.BUY
                ? entry.subtract(slDelta)
                : entry.add(slDelta);
        BigDecimal target = side == OrderSide.BUY
                ? entry.add(tpDelta)
                : entry.subtract(tpDelta);

        BigDecimal riskPerTrade = capital.multiply(BigDecimal.valueOf(0.01));
        BigDecimal perUnitRisk = entry.subtract(stopLoss).abs();
        if (perUnitRisk.compareTo(BigDecimal.ZERO) == 0) {
            perUnitRisk = BigDecimal.ONE;
        }

        int qty = riskPerTrade.divide(perUnitRisk, 0, RoundingMode.DOWN).intValue();
        qty = Math.max(qty, 1);

        BigDecimal reward = target.subtract(entry).abs();
        BigDecimal risk = entry.subtract(stopLoss).abs();
        BigDecimal riskReward = risk.compareTo(BigDecimal.ZERO) == 0
                ? BigDecimal.ZERO
                : reward.divide(risk, 4, RoundingMode.HALF_UP);

        return new TradePlanDto(
                side,
                entry.setScale(2, RoundingMode.HALF_UP),
                stopLoss.setScale(2, RoundingMode.HALF_UP),
                target.setScale(2, RoundingMode.HALF_UP),
                qty,
                riskReward
        );
    }
}
