package com.tradingapp.broker.api;

import java.math.BigDecimal;
import java.time.Instant;

public record QuoteData(
        String brokerSymbol,
        BigDecimal lastPrice,
        BigDecimal dayHigh,
        BigDecimal dayLow,
        BigDecimal volume,
        Instant timestamp
) {
}
