package com.tradingapp.candlepattern;

public enum CandlestickPattern {
    BULLISH_ENGULFING,
    BEARISH_ENGULFING,
    HAMMER,
    DOJI,
    NONE
}
