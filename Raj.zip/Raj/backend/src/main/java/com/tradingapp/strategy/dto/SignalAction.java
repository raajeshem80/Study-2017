package com.tradingapp.strategy.dto;

public enum SignalAction {
    BUY,
    SELL,
    WAIT,
    AVOID
}
