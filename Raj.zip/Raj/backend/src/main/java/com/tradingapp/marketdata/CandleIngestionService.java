package com.tradingapp.marketdata;

import com.tradingapp.broker.api.BrokerName;
import com.tradingapp.broker.api.CandleData;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CandleIngestionService {

    private final CandleRepository candleRepository;

    public CandleIngestionService(CandleRepository candleRepository) {
        this.candleRepository = candleRepository;
    }

    @Transactional
    public void storeCandles(BrokerName brokerName, String uiSymbol, List<CandleData> candles) {
        List<CandleEntity> entities = candles.stream().map(candle -> {
            CandleEntity entity = new CandleEntity();
            entity.setBroker(brokerName.name());
            entity.setSymbol(uiSymbol);
            entity.setTimeframe(candle.timeframe());
            entity.setTimestamp(candle.timestamp());
            entity.setOpen(candle.open());
            entity.setHigh(candle.high());
            entity.setLow(candle.low());
            entity.setClose(candle.close());
            entity.setVolume(candle.volume());
            return entity;
        }).toList();
        candleRepository.saveAll(entities);
    }
}
