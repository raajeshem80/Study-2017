package com.tradingapp.execution;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class OrderGuardInterceptor implements HandlerInterceptor {

    private final OrderGuardService orderGuardService;

    public OrderGuardInterceptor(OrderGuardService orderGuardService) {
        this.orderGuardService = orderGuardService;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        String apiKey = request.getHeader("X-API-KEY");
        String clientIp = request.getHeader("X-Forwarded-For");
        if (clientIp == null || clientIp.isBlank()) {
            clientIp = request.getRemoteAddr();
        } else if (clientIp.contains(",")) {
            clientIp = clientIp.split(",")[0].trim();
        }
        orderGuardService.validateRequestKeyAndIp(apiKey, clientIp);
        return true;
    }
}
