package com.tradingapp.websocket.dto;

import com.tradingapp.broker.api.OrderSide;
import java.math.BigDecimal;
import java.time.Instant;

public record TradePlanWsMessage(
        String version,
        String broker,
        String symbol,
        OrderSide side,
        BigDecimal entry,
        BigDecimal stopLoss,
        BigDecimal target,
        int quantity,
        BigDecimal riskReward,
        Instant timestamp
) {
}
