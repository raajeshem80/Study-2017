package com.tradingapp.broker.api;

import java.util.List;
import reactor.core.publisher.Flux;

public interface BrokerTickSubscriber {
    Flux<TickData> subscribeTicks(List<String> brokerSymbols);
}
