package com.tradingapp.broker.kite;

import com.tradingapp.config.AppProperties;
import org.springframework.stereotype.Service;

@Service
public class KiteAuthService {

    private final AppProperties appProperties;

    public KiteAuthService(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    public String accessToken() {
        return appProperties.getBroker().getKite().getAccessToken();
    }
}
