package com.tradingapp.symbol;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "symbol_mapping")
public class SymbolMappingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "symbol", nullable = false, unique = true)
    private String symbol;

    @Column(name = "kite_symbol", nullable = false)
    private String kiteSymbol;

    @Column(name = "upstox_symbol", nullable = false)
    private String upstoxSymbol;

    public Long getId() {
        return id;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getKiteSymbol() {
        return kiteSymbol;
    }

    public void setKiteSymbol(String kiteSymbol) {
        this.kiteSymbol = kiteSymbol;
    }

    public String getUpstoxSymbol() {
        return upstoxSymbol;
    }

    public void setUpstoxSymbol(String upstoxSymbol) {
        this.upstoxSymbol = upstoxSymbol;
    }
}
