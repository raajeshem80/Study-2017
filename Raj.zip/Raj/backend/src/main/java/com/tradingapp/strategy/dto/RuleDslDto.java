package com.tradingapp.strategy.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;

public record RuleDslDto(
        @NotBlank String operator,
        @NotEmpty List<ConditionDto> conditions,
        List<RuleDslDto> groups
) {
    public record ConditionDto(
            @NotBlank String field,
            @NotBlank String comparator,
            @NotBlank String value
    ) {
    }
}
