package com.tradingapp.api;

import com.tradingapp.api.dto.SymbolMapResponse;
import com.tradingapp.symbol.SymbolMappingEntity;
import com.tradingapp.symbol.SymbolMappingService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/symbols")
public class SymbolController {

    private final SymbolMappingService symbolMappingService;

    public SymbolController(SymbolMappingService symbolMappingService) {
        this.symbolMappingService = symbolMappingService;
    }

    @GetMapping("/map/{uiSymbol}")
    public SymbolMapResponse map(@PathVariable String uiSymbol) {
        SymbolMappingEntity mapping = symbolMappingService.getByUiSymbol(uiSymbol);
        return new SymbolMapResponse(mapping.getSymbol(), mapping.getKiteSymbol(), mapping.getUpstoxSymbol());
    }
}
