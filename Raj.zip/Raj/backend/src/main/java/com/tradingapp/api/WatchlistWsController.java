package com.tradingapp.api;

import com.tradingapp.broker.api.BrokerClient;
import com.tradingapp.broker.api.BrokerName;
import com.tradingapp.broker.routing.BrokerRouter;
import com.tradingapp.symbol.SymbolMappingService;
import com.tradingapp.websocket.MarketStreamPublisher;
import com.tradingapp.websocket.dto.TickWsMessage;
import com.tradingapp.websocket.dto.WatchlistSubscriptionRequest;
import java.util.List;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.stereotype.Controller;

@Controller
public class WatchlistWsController {

    private final BrokerRouter brokerRouter;
    private final SymbolMappingService symbolMappingService;
    private final MarketStreamPublisher marketStreamPublisher;

    public WatchlistWsController(
            BrokerRouter brokerRouter,
            SymbolMappingService symbolMappingService,
            MarketStreamPublisher marketStreamPublisher
    ) {
        this.brokerRouter = brokerRouter;
        this.symbolMappingService = symbolMappingService;
        this.marketStreamPublisher = marketStreamPublisher;
    }

    @MessageMapping("/watchlist")
    public void subscribeWatchlist(WatchlistSubscriptionRequest request) {
        if (request == null || request.symbols() == null || request.symbols().isEmpty()) {
            return;
        }
        BrokerClient brokerClient = brokerRouter.route(request.broker());
        BrokerName brokerName = brokerClient.brokerName();
        List<String> brokerSymbols = request.symbols().stream()
                .map(symbol -> symbolMappingService.resolveBrokerSymbol(brokerName, symbol))
                .toList();

        brokerClient.subscribeTicks(brokerSymbols).subscribe(tick -> {
            String uiSymbol = request.symbols().stream().filter(s -> {
                String mapped = symbolMappingService.resolveBrokerSymbol(brokerName, s);
                return mapped.equalsIgnoreCase(tick.brokerSymbol());
            }).findFirst().orElse(tick.brokerSymbol());

            marketStreamPublisher.publishTick(uiSymbol, new TickWsMessage(
                    "v1",
                    request.broker(),
                    uiSymbol,
                    tick.lastPrice(),
                    tick.volume(),
                    tick.timestamp()
            ));
        });
    }
}
