package com.tradingapp.broker.api;

import java.time.Instant;
import java.util.List;

public interface BrokerClient extends BrokerTickSubscriber, BrokerHistoricalClient, BrokerOrderClient {

    BrokerName brokerName();

    QuoteData fetchQuote(String brokerSymbol);

    @Override
    List<CandleData> fetchHistoricalCandles(String brokerSymbol, String timeframe, Instant from, Instant to);
}
