package com.tradingapp.broker.api;

public enum BrokerName {
    KITE,
    UPSTOX,
    MOCK
}
