package com.tradingapp.persistence.repositories;

import com.tradingapp.persistence.entities.BacktestRunEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BacktestRunRepository extends JpaRepository<BacktestRunEntity, Long> {
}
