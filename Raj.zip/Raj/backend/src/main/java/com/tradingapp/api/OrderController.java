package com.tradingapp.api;

import com.tradingapp.execution.OrderExecutionService;
import com.tradingapp.execution.dto.OrderResponse;
import com.tradingapp.execution.dto.PlaceOrderRequest;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderExecutionService orderExecutionService;

    public OrderController(OrderExecutionService orderExecutionService) {
        this.orderExecutionService = orderExecutionService;
    }

    @PostMapping("/place")
    public OrderResponse place(@Valid @RequestBody PlaceOrderRequest request) {
        return orderExecutionService.placeOrder(request);
    }

    @PostMapping("/{orderId}/cancel")
    public OrderResponse cancel(
            @PathVariable String orderId,
            @RequestParam String broker,
            @RequestParam String accountId
    ) {
        return orderExecutionService.cancelOrder(broker, orderId, accountId);
    }

    @GetMapping("/{orderId}")
    public OrderResponse status(
            @PathVariable String orderId,
            @RequestParam String broker,
            @RequestParam String accountId
    ) {
        return orderExecutionService.getOrder(broker, orderId, accountId);
    }
}
