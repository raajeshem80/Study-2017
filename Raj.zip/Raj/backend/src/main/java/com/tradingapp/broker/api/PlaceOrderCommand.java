package com.tradingapp.broker.api;

import java.math.BigDecimal;

public record PlaceOrderCommand(
        String accountId,
        String brokerSymbol,
        OrderSide side,
        int quantity,
        OrderType orderType,
        BigDecimal price
) {
}
