package com.tradingapp.broker.upstox;

import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class UpstoxWsHandler {

    public void subscribe(List<String> symbols) {
        // Placeholder for real Upstox websocket subscription wiring.
    }
}
