package com.tradingapp.backtest.dto;

import com.tradingapp.strategy.dto.RuleDslDto;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.Instant;

public record BacktestRequest(
        @NotBlank String broker,
        @NotBlank String symbol,
        @NotBlank String timeframe,
        @NotNull Instant from,
        @NotNull Instant to,
        @NotNull BigDecimal capital,
        @Valid RuleDslDto rule
) {
}
