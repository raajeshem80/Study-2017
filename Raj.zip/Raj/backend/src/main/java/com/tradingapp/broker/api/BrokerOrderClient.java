package com.tradingapp.broker.api;

public interface BrokerOrderClient {
    String placeOrder(PlaceOrderCommand command);

    void cancelOrder(String orderId, String accountId);

    OrderSnapshot getOrder(String orderId, String accountId);
}
