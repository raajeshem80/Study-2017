package com.tradingapp.indicator;

import com.tradingapp.broker.api.CandleData;
import com.tradingapp.indicator.calculators.AtrCalculator;
import com.tradingapp.indicator.calculators.EmaCalculator;
import com.tradingapp.indicator.calculators.RsiCalculator;
import com.tradingapp.indicator.calculators.VwapCalculator;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class IndicatorService {

    private final EmaCalculator emaCalculator = new EmaCalculator();
    private final RsiCalculator rsiCalculator = new RsiCalculator();
    private final VwapCalculator vwapCalculator = new VwapCalculator();
    private final AtrCalculator atrCalculator = new AtrCalculator();

    public IndicatorSnapshot calculateDefaults(List<CandleData> candles) {
        List<BigDecimal> closes = candles.stream().map(CandleData::close).toList();
        BigDecimal ema50 = emaCalculator.calculate(closes, 50);
        BigDecimal rsi14 = rsiCalculator.calculate(closes, 14);
        BigDecimal vwap = vwapCalculator.calculate(candles);
        BigDecimal atr14 = atrCalculator.calculate(candles, 14);
        return new IndicatorSnapshot(ema50, rsi14, vwap, atr14);
    }
}
