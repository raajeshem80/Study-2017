package com.tradingapp.broker.api;

public enum OrderSide {
    BUY,
    SELL
}
