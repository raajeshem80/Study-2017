package com.tradingapp.broker.upstox;

import com.tradingapp.config.AppProperties;
import org.springframework.stereotype.Service;

@Service
public class UpstoxAuthService {

    private final AppProperties appProperties;

    public UpstoxAuthService(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    public String accessToken() {
        return appProperties.getBroker().getUpstox().getAccessToken();
    }
}
