package com.tradingapp.execution;

import com.tradingapp.infra.cache.ParameterCacheService;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class OrderGuardService {

    private final ParameterCacheService parameterCacheService;

    public OrderGuardService(ParameterCacheService parameterCacheService) {
        this.parameterCacheService = parameterCacheService;
    }

    public void validateRequestKeyAndIp(String apiKey, String clientIp) {
        if (parameterCacheService.killSwitch()) {
            throw new SecurityException("Global kill switch is enabled");
        }
        String configuredApiKey = parameterCacheService.apiKey();
        if (configuredApiKey == null || configuredApiKey.isBlank() || !configuredApiKey.equals(apiKey)) {
            throw new SecurityException("Invalid API key for order operation");
        }
        List<String> ipAllowlist = parameterCacheService.ipAllowlist();
        if (!ipAllowlist.isEmpty() && !ipAllowlist.contains(clientIp)) {
            throw new SecurityException("IP address is not allowlisted for order operation");
        }
    }

    public void validateAccount(String accountId) {
        List<String> accountAllowlist = parameterCacheService.accountAllowlist();
        if (!accountAllowlist.isEmpty() && !accountAllowlist.contains(accountId)) {
            throw new SecurityException("Account is not allowlisted for order operation");
        }
    }

    public boolean dryRunEnabled() {
        return parameterCacheService.dryRun();
    }
}
