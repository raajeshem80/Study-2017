package com.tradingapp.infra.cache;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tradingapp.config.AppProperties;
import com.tradingapp.persistence.entities.AppSettingEntity;
import com.tradingapp.persistence.repositories.AppSettingRepository;
import jakarta.annotation.PostConstruct;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class ParameterCacheService {

    private final AppSettingRepository appSettingRepository;
    private final AppProperties appProperties;
    private final ObjectMapper objectMapper;
    private final Map<String, String> cache = new ConcurrentHashMap<>();

    public ParameterCacheService(AppSettingRepository appSettingRepository, AppProperties appProperties, ObjectMapper objectMapper) {
        this.appSettingRepository = appSettingRepository;
        this.appProperties = appProperties;
        this.objectMapper = objectMapper;
    }

    @PostConstruct
    public void init() {
        reload();
    }

    @Scheduled(fixedDelay = 20_000)
    public void reload() {
        for (AppSettingEntity entry : appSettingRepository.findAll()) {
            cache.put(entry.getSettingKey(), entry.getSettingValue());
        }
    }

    public boolean killSwitch() {
        return Boolean.parseBoolean(cache.getOrDefault("order.kill_switch", String.valueOf(appProperties.getOrderGuard().isKillSwitch())));
    }

    public boolean dryRun() {
        return Boolean.parseBoolean(cache.getOrDefault("order.dry_run", String.valueOf(appProperties.getOrderGuard().isDryRun())));
    }

    public String apiKey() {
        return cache.getOrDefault("order.api_key", appProperties.getOrderGuard().getApiKey());
    }

    public List<String> ipAllowlist() {
        String raw = cache.get("order.ip_allowlist");
        if (raw == null || raw.isBlank()) {
            return appProperties.getOrderGuard().getIpAllowlist();
        }
        try {
            return objectMapper.readValue(raw, new TypeReference<>() {
            });
        } catch (Exception ex) {
            return appProperties.getOrderGuard().getIpAllowlist();
        }
    }

    public List<String> accountAllowlist() {
        String raw = cache.get("order.account_allowlist");
        if (raw == null || raw.isBlank()) {
            return appProperties.getOrderGuard().getAccountAllowlist();
        }
        try {
            return objectMapper.readValue(raw, new TypeReference<>() {
            });
        } catch (Exception ex) {
            return appProperties.getOrderGuard().getAccountAllowlist();
        }
    }

    public Map<String, String> asMap() {
        return Map.copyOf(cache);
    }
}
