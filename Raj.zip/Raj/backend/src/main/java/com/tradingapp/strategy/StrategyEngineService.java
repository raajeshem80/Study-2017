package com.tradingapp.strategy;

import com.tradingapp.broker.api.CandleData;
import com.tradingapp.candlepattern.CandlestickPattern;
import com.tradingapp.candlepattern.CandlestickPatternService;
import com.tradingapp.indicator.IndicatorService;
import com.tradingapp.indicator.IndicatorSnapshot;
import com.tradingapp.sr.SupportResistanceLevels;
import com.tradingapp.sr.SupportResistanceService;
import com.tradingapp.strategy.dto.SignalDto;
import com.tradingapp.strategy.dto.StrategyContextDto;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class StrategyEngineService {

    private final IndicatorService indicatorService;
    private final SupportResistanceService supportResistanceService;
    private final CandlestickPatternService candlestickPatternService;
    private final ScoreEngine scoreEngine;

    public StrategyEngineService(
            IndicatorService indicatorService,
            SupportResistanceService supportResistanceService,
            CandlestickPatternService candlestickPatternService,
            ScoreEngine scoreEngine
    ) {
        this.indicatorService = indicatorService;
        this.supportResistanceService = supportResistanceService;
        this.candlestickPatternService = candlestickPatternService;
        this.scoreEngine = scoreEngine;
    }

    public StrategyBundle evaluate(String broker, String symbol, List<CandleData> candles5m, List<CandleData> candles15m) {
        if (candles5m == null || candles5m.isEmpty() || candles15m == null || candles15m.isEmpty()) {
            throw new IllegalArgumentException("Insufficient candle data for strategy evaluation");
        }

        IndicatorSnapshot indicators5m = indicatorService.calculateDefaults(candles5m);
        IndicatorSnapshot indicators15m = indicatorService.calculateDefaults(candles15m);
        SupportResistanceLevels levels = supportResistanceService.calculateLevels(candles15m);
        CandlestickPattern pattern = candlestickPatternService.detect(candles5m);

        BigDecimal price = candles5m.getLast().close();
        BigDecimal averageVolume = candles5m.stream()
                .map(CandleData::volume)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .divide(BigDecimal.valueOf(candles5m.size()), 4, RoundingMode.HALF_UP);
        BigDecimal latestVolume = candles5m.getLast().volume();

        boolean trendBullish = price.compareTo(indicators15m.ema50()) > 0;
        boolean trendBearish = price.compareTo(indicators15m.ema50()) < 0;
        boolean nearSupport = supportResistanceService.nearSupport(price, levels);
        boolean nearResistance = supportResistanceService.nearResistance(price, levels);

        StrategyContextDto context = new StrategyContextDto(
                broker,
                symbol,
                price,
                trendBullish,
                trendBearish,
                nearSupport,
                nearResistance,
                pattern,
                indicators5m.rsi14(),
                indicators5m.vwap(),
                indicators5m.atr14(),
                latestVolume,
                averageVolume
        );

        ScoreEngine.ScoreResult scoreResult = scoreEngine.score(context);

        SignalDto signal = new SignalDto(
                broker,
                symbol,
                scoreResult.action(),
                scoreResult.score(),
                price,
                scoreResult.reasons(),
                Instant.now()
        );
        return new StrategyBundle(signal, context, indicators5m, indicators15m, levels);
    }

    public record StrategyBundle(
            SignalDto signal,
            StrategyContextDto context,
            IndicatorSnapshot indicators5m,
            IndicatorSnapshot indicators15m,
            SupportResistanceLevels levels
    ) {
    }
}
