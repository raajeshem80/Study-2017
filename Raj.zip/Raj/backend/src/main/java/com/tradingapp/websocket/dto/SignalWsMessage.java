package com.tradingapp.websocket.dto;

import com.tradingapp.strategy.dto.SignalAction;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

public record SignalWsMessage(
        String version,
        String broker,
        String symbol,
        SignalAction action,
        int score,
        BigDecimal price,
        List<String> reasons,
        Instant timestamp
) {
}
