package com.tradingapp.broker.api;

public enum OrderType {
    MARKET,
    LIMIT
}
