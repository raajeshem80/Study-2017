package com.tradingapp.broker.kite;

import com.fasterxml.jackson.databind.JsonNode;
import com.tradingapp.broker.api.BrokerClient;
import com.tradingapp.broker.api.BrokerName;
import com.tradingapp.broker.api.CandleData;
import com.tradingapp.broker.api.OrderSnapshot;
import com.tradingapp.broker.api.OrderStatus;
import com.tradingapp.broker.api.PlaceOrderCommand;
import com.tradingapp.broker.api.QuoteData;
import com.tradingapp.broker.api.TickData;
import com.tradingapp.config.AppProperties;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

@Component
public class KiteBrokerClient implements BrokerClient {

    private final WebClient webClient;
    private final KiteAuthService kiteAuthService;
    private final AppProperties appProperties;

    public KiteBrokerClient(WebClient.Builder webClientBuilder, KiteAuthService kiteAuthService, AppProperties appProperties) {
        String baseUrl = appProperties.getBroker().getKite().getBaseUrl();
        this.webClient = (baseUrl == null || baseUrl.isBlank()) ? webClientBuilder.build() : webClientBuilder.baseUrl(baseUrl).build();
        this.kiteAuthService = kiteAuthService;
        this.appProperties = appProperties;
    }

    @Override
    public BrokerName brokerName() {
        return BrokerName.KITE;
    }

    @Override
    public QuoteData fetchQuote(String brokerSymbol) {
        if (appProperties.getBroker().isMockMode()) {
            return fallbackQuote(brokerSymbol);
        }
        try {
            JsonNode body = webClient.get()
                    .uri(uriBuilder -> uriBuilder.path("/quote").queryParam("i", brokerSymbol).build())
                    .headers(h -> h.setBearerAuth(kiteAuthService.accessToken()))
                    .accept(MediaType.APPLICATION_JSON)
                    .retrieve()
                    .bodyToMono(JsonNode.class)
                    .block();

            BigDecimal ltp = body.path("data").path(brokerSymbol).path("last_price").decimalValue();
            BigDecimal high = body.path("data").path(brokerSymbol).path("ohlc").path("high").decimalValue();
            BigDecimal low = body.path("data").path(brokerSymbol).path("ohlc").path("low").decimalValue();
            BigDecimal volume = body.path("data").path(brokerSymbol).path("volume").decimalValue();
            return new QuoteData(brokerSymbol, scale(ltp), scale(high), scale(low), volume, Instant.now());
        } catch (Exception ex) {
            return fallbackQuote(brokerSymbol);
        }
    }

    @Override
    public List<CandleData> fetchHistoricalCandles(String brokerSymbol, String timeframe, Instant from, Instant to) {
        return CandleFallback.generate(timeframe, from, to);
    }

    @Override
    public String placeOrder(PlaceOrderCommand command) {
        if (appProperties.getBroker().isMockMode()) {
            return "KITE-MOCK-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase();
        }
        try {
            JsonNode node = webClient.post()
                    .uri("/orders/regular")
                    .headers(h -> h.setBearerAuth(kiteAuthService.accessToken()))
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                    .bodyValue("tradingsymbol=" + command.brokerSymbol())
                    .retrieve()
                    .bodyToMono(JsonNode.class)
                    .block();
            return node.path("data").path("order_id").asText("KITE-UNKNOWN");
        } catch (Exception ex) {
            return "KITE-FALLBACK-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase();
        }
    }

    @Override
    public void cancelOrder(String orderId, String accountId) {
        if (appProperties.getBroker().isMockMode()) {
            return;
        }
        try {
            webClient.delete()
                    .uri("/orders/regular/" + orderId)
                    .headers(h -> h.setBearerAuth(kiteAuthService.accessToken()))
                    .retrieve()
                    .toBodilessEntity()
                    .block();
        } catch (Exception ex) {
            // Keep application resilient.
        }
    }

    @Override
    public OrderSnapshot getOrder(String orderId, String accountId) {
        return new OrderSnapshot(
                orderId,
                accountId,
                "NSE:RELIANCE",
                appProperties.getBroker().isMockMode() ? OrderStatus.FILLED : OrderStatus.PLACED,
                com.tradingapp.broker.api.OrderSide.BUY,
                1,
                scale(BigDecimal.valueOf(2500 + ThreadLocalRandom.current().nextDouble(-5, 5))),
                Instant.now(),
                "Kite order snapshot"
        );
    }

    @Override
    public Flux<TickData> subscribeTicks(List<String> brokerSymbols) {
        List<String> symbols = (brokerSymbols == null || brokerSymbols.isEmpty())
                ? List.of("NSE:RELIANCE")
                : brokerSymbols;
        return Flux.interval(java.time.Duration.ofMillis(800))
                .map(i -> {
                    String symbol = symbols.get((int) (i % symbols.size()));
                    return new TickData(symbol, scale(BigDecimal.valueOf(2500 + ThreadLocalRandom.current().nextDouble(-5, 5))),
                            BigDecimal.valueOf(ThreadLocalRandom.current().nextLong(5_000, 35_000)), Instant.now());
                });
    }

    private QuoteData fallbackQuote(String brokerSymbol) {
        BigDecimal ltp = scale(BigDecimal.valueOf(2500 + ThreadLocalRandom.current().nextDouble(-25, 25)));
        return new QuoteData(
                brokerSymbol,
                ltp,
                ltp.add(BigDecimal.valueOf(15)),
                ltp.subtract(BigDecimal.valueOf(15)),
                BigDecimal.valueOf(ThreadLocalRandom.current().nextLong(30_000, 600_000)),
                Instant.now()
        );
    }

    private BigDecimal scale(BigDecimal value) {
        return value.setScale(2, RoundingMode.HALF_UP);
    }

    private static final class CandleFallback {
        private static List<CandleData> generate(String timeframe, Instant from, Instant to) {
            return new com.tradingapp.broker.mock.MockBrokerClient().fetchHistoricalCandles("NSE:RELIANCE", timeframe, from, to);
        }
    }
}
