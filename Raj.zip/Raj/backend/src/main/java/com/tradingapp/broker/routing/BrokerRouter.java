package com.tradingapp.broker.routing;

import com.tradingapp.broker.api.BrokerClient;
import com.tradingapp.broker.api.BrokerName;
import com.tradingapp.config.AppProperties;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.stereotype.Component;

@Component
public class BrokerRouter {

    private final Map<BrokerName, BrokerClient> clients = new EnumMap<>(BrokerName.class);
    private final AppProperties appProperties;

    public BrokerRouter(List<BrokerClient> brokerClients, AppProperties appProperties) {
        this.appProperties = appProperties;
        for (BrokerClient brokerClient : brokerClients) {
            clients.put(brokerClient.brokerName(), brokerClient);
        }
    }

    public BrokerClient route(String brokerName) {
        if (brokerName == null || brokerName.isBlank()) {
            return fallbackClient();
        }

        String normalized = brokerName.trim().toUpperCase(Locale.ROOT);
        BrokerName name = switch (normalized) {
            case "KITE", "ZERODHA" -> BrokerName.KITE;
            case "UPSTOX" -> BrokerName.UPSTOX;
            case "MOCK", "PAPER" -> BrokerName.MOCK;
            default -> throw new IllegalArgumentException("Unsupported broker: " + brokerName);
        };
        return appProperties.getBroker().isMockMode() ? fallbackClient() : clients.getOrDefault(name, fallbackClient());
    }

    public BrokerClient fallbackClient() {
        BrokerClient fallback = clients.get(BrokerName.MOCK);
        if (fallback == null) {
            throw new IllegalStateException("Mock broker client is required");
        }
        return fallback;
    }
}
