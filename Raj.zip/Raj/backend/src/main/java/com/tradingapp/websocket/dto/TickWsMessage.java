package com.tradingapp.websocket.dto;

import java.math.BigDecimal;
import java.time.Instant;

public record TickWsMessage(
        String version,
        String broker,
        String symbol,
        BigDecimal price,
        BigDecimal volume,
        Instant timestamp
) {
}
