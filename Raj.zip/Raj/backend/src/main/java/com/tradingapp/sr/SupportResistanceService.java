package com.tradingapp.sr;

import com.tradingapp.broker.api.CandleData;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class SupportResistanceService {

    public SupportResistanceLevels calculateLevels(List<CandleData> candles) {
        if (candles == null || candles.isEmpty()) {
            return new SupportResistanceLevels(BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO);
        }

        CandleData latest = candles.getLast();
        BigDecimal pivot = latest.high().add(latest.low()).add(latest.close()).divide(BigDecimal.valueOf(3), 4, RoundingMode.HALF_UP);
        BigDecimal support = pivot.multiply(BigDecimal.valueOf(2)).subtract(latest.high()).setScale(4, RoundingMode.HALF_UP);
        BigDecimal resistance = pivot.multiply(BigDecimal.valueOf(2)).subtract(latest.low()).setScale(4, RoundingMode.HALF_UP);

        BigDecimal swingLow = candles.stream().map(CandleData::low).min(BigDecimal::compareTo).orElse(latest.low());
        BigDecimal swingHigh = candles.stream().map(CandleData::high).max(BigDecimal::compareTo).orElse(latest.high());

        return new SupportResistanceLevels(pivot, support, resistance, swingLow, swingHigh);
    }

    public boolean nearSupport(BigDecimal price, SupportResistanceLevels levels) {
        return withinTolerance(price, levels.support()) || withinTolerance(price, levels.swingLow());
    }

    public boolean nearResistance(BigDecimal price, SupportResistanceLevels levels) {
        return withinTolerance(price, levels.resistance()) || withinTolerance(price, levels.swingHigh());
    }

    private boolean withinTolerance(BigDecimal value, BigDecimal level) {
        if (level.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        BigDecimal delta = value.subtract(level).abs();
        BigDecimal tolerance = level.multiply(BigDecimal.valueOf(0.005));
        return delta.compareTo(tolerance) <= 0;
    }
}
