package com.tradingapp.api.dto;

import com.tradingapp.risk.dto.TradePlanDto;
import com.tradingapp.strategy.dto.SignalDto;

public record LiveAnalysisResponse(
        SignalDto signal,
        TradePlanDto tradePlan,
        IndicatorView indicators,
        LevelView levels
) {
    public record IndicatorView(
            String ema50,
            String rsi14,
            String vwap,
            String atr14
    ) {
    }

    public record LevelView(
            String pivot,
            String support,
            String resistance,
            String swingLow,
            String swingHigh
    ) {
    }
}
