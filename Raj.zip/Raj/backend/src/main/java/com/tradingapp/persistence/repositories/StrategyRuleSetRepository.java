package com.tradingapp.persistence.repositories;

import com.tradingapp.persistence.entities.StrategyRuleSetEntity;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StrategyRuleSetRepository extends JpaRepository<StrategyRuleSetEntity, Long> {
    Optional<StrategyRuleSetEntity> findTopBySymbolAndActiveTrueOrderByUpdatedAtDesc(String symbol);
}
