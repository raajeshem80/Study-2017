package com.tradingapp.strategy;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tradingapp.api.dto.RuleEvaluateRequest;
import com.tradingapp.persistence.entities.StrategyRuleSetEntity;
import com.tradingapp.persistence.repositories.StrategyRuleSetRepository;
import com.tradingapp.strategy.dto.RuleDslDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class StrategyRuleService {

    private final StrategyRuleSetRepository strategyRuleSetRepository;
    private final RuleDslEvaluator ruleDslEvaluator;
    private final ObjectMapper objectMapper;

    public StrategyRuleService(
            StrategyRuleSetRepository strategyRuleSetRepository,
            RuleDslEvaluator ruleDslEvaluator,
            ObjectMapper objectMapper
    ) {
        this.strategyRuleSetRepository = strategyRuleSetRepository;
        this.ruleDslEvaluator = ruleDslEvaluator;
        this.objectMapper = objectMapper;
    }

    @Transactional
    public RuleDslEvaluator.RuleEvaluationResult evaluateAndSave(RuleEvaluateRequest request) {
        RuleDslEvaluator.RuleEvaluationResult result = ruleDslEvaluator.evaluate(request.rule(), request.context());
        saveRuleSet(request.name(), request.symbol(), request.rule());
        return result;
    }

    public RuleDslDto loadActiveRule(String symbol) {
        return strategyRuleSetRepository.findTopBySymbolAndActiveTrueOrderByUpdatedAtDesc(symbol)
                .map(entity -> readRule(entity.getDslJson()))
                .orElse(null);
    }

    private void saveRuleSet(String name, String symbol, RuleDslDto rule) {
        StrategyRuleSetEntity entity = strategyRuleSetRepository.findTopBySymbolAndActiveTrueOrderByUpdatedAtDesc(symbol)
                .orElseGet(StrategyRuleSetEntity::new);
        entity.setName(name);
        entity.setSymbol(symbol);
        entity.setDslJson(writeRule(rule));
        entity.setActive(true);
        strategyRuleSetRepository.save(entity);
    }

    private String writeRule(RuleDslDto rule) {
        try {
            return objectMapper.writeValueAsString(rule);
        } catch (JsonProcessingException ex) {
            throw new IllegalArgumentException("Failed to serialize rule DSL", ex);
        }
    }

    private RuleDslDto readRule(String json) {
        try {
            return objectMapper.readValue(json, RuleDslDto.class);
        } catch (JsonProcessingException ex) {
            throw new IllegalArgumentException("Failed to deserialize rule DSL", ex);
        }
    }
}
