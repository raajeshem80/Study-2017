package com.tradingapp.broker.kite;

import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class KiteWsHandler {

    public void subscribe(List<String> symbols) {
        // Placeholder for real Kite websocket subscription wiring.
    }
}
