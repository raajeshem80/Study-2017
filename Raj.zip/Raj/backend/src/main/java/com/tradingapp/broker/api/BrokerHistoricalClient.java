package com.tradingapp.broker.api;

import java.time.Instant;
import java.util.List;

public interface BrokerHistoricalClient {
    List<CandleData> fetchHistoricalCandles(String brokerSymbol, String timeframe, Instant from, Instant to);
}
