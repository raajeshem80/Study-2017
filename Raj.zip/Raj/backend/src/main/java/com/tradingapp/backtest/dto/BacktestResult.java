package com.tradingapp.backtest.dto;

import java.math.BigDecimal;
import java.util.List;

public record BacktestResult(
        String broker,
        String symbol,
        int totalTrades,
        BigDecimal winRate,
        BigDecimal netPnl,
        BigDecimal maxDrawdown,
        BigDecimal expectancy,
        List<BacktestTradeResult> trades
) {
}
