package com.tradingapp.api;

import com.tradingapp.backtest.BacktestService;
import com.tradingapp.backtest.dto.BacktestRequest;
import com.tradingapp.backtest.dto.BacktestResult;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/backtest")
public class BacktestController {

    private final BacktestService backtestService;

    public BacktestController(BacktestService backtestService) {
        this.backtestService = backtestService;
    }

    @PostMapping
    public BacktestResult run(@Valid @RequestBody BacktestRequest request) {
        return backtestService.run(request);
    }
}
