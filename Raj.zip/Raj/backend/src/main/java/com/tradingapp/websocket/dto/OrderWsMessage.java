package com.tradingapp.websocket.dto;

import com.tradingapp.broker.api.OrderStatus;
import java.time.Instant;

public record OrderWsMessage(
        String version,
        String broker,
        String accountId,
        String orderId,
        OrderStatus status,
        String message,
        Instant timestamp
) {
}
