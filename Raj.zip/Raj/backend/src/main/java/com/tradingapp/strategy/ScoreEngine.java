package com.tradingapp.strategy;

import com.tradingapp.candlepattern.CandlestickPattern;
import com.tradingapp.strategy.dto.SignalAction;
import com.tradingapp.strategy.dto.StrategyContextDto;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class ScoreEngine {

    public ScoreResult score(StrategyContextDto context) {
        int bullish = 0;
        int bearish = 0;
        List<String> reasons = new ArrayList<>();

        if (context.trendBullish()) {
            bullish += 30;
            reasons.add("15m trend bullish (+30)");
        } else if (context.trendBearish()) {
            bearish += 30;
            reasons.add("15m trend bearish (+30)");
        }

        if (context.nearSupport()) {
            bullish += 20;
            reasons.add("Near support/swing-low (+20)");
        }
        if (context.nearResistance()) {
            bearish += 20;
            reasons.add("Near resistance/swing-high (+20)");
        }

        if (context.pattern() == CandlestickPattern.BULLISH_ENGULFING || context.pattern() == CandlestickPattern.HAMMER) {
            bullish += 20;
            reasons.add("Bullish candlestick pattern (+20)");
        } else if (context.pattern() == CandlestickPattern.BEARISH_ENGULFING) {
            bearish += 20;
            reasons.add("Bearish candlestick pattern (+20)");
        }

        if (context.rsi().compareTo(BigDecimal.valueOf(55)) >= 0 && context.price().compareTo(context.vwap()) > 0) {
            bullish += 20;
            reasons.add("RSI and VWAP bullish confirmation (+20)");
        } else if (context.rsi().compareTo(BigDecimal.valueOf(45)) <= 0 && context.price().compareTo(context.vwap()) < 0) {
            bearish += 20;
            reasons.add("RSI and VWAP bearish confirmation (+20)");
        }

        if (context.latestVolume().compareTo(context.averageVolume()) > 0) {
            if (bullish >= bearish) {
                bullish += 10;
                reasons.add("Volume confirmation bullish (+10)");
            } else {
                bearish += 10;
                reasons.add("Volume confirmation bearish (+10)");
            }
        }

        int score = Math.max(bullish, bearish);
        SignalAction direction = bullish >= bearish ? SignalAction.BUY : SignalAction.SELL;
        SignalAction finalAction = resolve(score, direction);
        return new ScoreResult(finalAction, score, reasons);
    }

    private SignalAction resolve(int score, SignalAction directional) {
        if (score >= 75) {
            return directional;
        }
        if (score >= 55) {
            return SignalAction.WAIT;
        }
        return SignalAction.AVOID;
    }

    public record ScoreResult(SignalAction action, int score, List<String> reasons) {
    }
}
