package com.tradingapp.indicator.calculators;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

public class EmaCalculator {

    public BigDecimal calculate(List<BigDecimal> prices, int period) {
        if (prices == null || prices.isEmpty()) {
            return BigDecimal.ZERO;
        }
        double multiplier = 2.0 / (period + 1.0);
        double ema = prices.getFirst().doubleValue();
        for (int i = 1; i < prices.size(); i++) {
            double price = prices.get(i).doubleValue();
            ema = (price - ema) * multiplier + ema;
        }
        return BigDecimal.valueOf(ema).setScale(4, RoundingMode.HALF_UP);
    }
}
