package com.tradingapp.broker.api;

public enum OrderStatus {
    RECEIVED,
    PLACED,
    FILLED,
    REJECTED,
    CANCELLED
}
