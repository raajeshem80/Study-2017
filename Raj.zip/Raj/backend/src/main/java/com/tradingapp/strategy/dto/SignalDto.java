package com.tradingapp.strategy.dto;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

public record SignalDto(
        String broker,
        String symbol,
        SignalAction action,
        int score,
        BigDecimal lastPrice,
        List<String> reasons,
        Instant timestamp
) {
}
