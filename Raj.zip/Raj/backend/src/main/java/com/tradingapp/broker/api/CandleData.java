package com.tradingapp.broker.api;

import java.math.BigDecimal;
import java.time.Instant;

public record CandleData(
        Instant timestamp,
        BigDecimal open,
        BigDecimal high,
        BigDecimal low,
        BigDecimal close,
        BigDecimal volume,
        String timeframe
) {
}
