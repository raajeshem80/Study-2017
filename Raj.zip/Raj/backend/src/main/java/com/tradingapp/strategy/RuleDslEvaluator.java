package com.tradingapp.strategy;

import com.tradingapp.strategy.dto.RuleDslDto;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.stereotype.Component;

@Component
public class RuleDslEvaluator {

    public RuleEvaluationResult evaluate(RuleDslDto rule, Map<String, Object> context) {
        List<String> matched = new ArrayList<>();
        boolean result = evaluateGroup(rule, context, matched);
        return new RuleEvaluationResult(result, matched);
    }

    private boolean evaluateGroup(RuleDslDto rule, Map<String, Object> context, List<String> matched) {
        String op = normalizeOperator(rule.operator());
        List<Boolean> checks = new ArrayList<>();

        for (RuleDslDto.ConditionDto condition : rule.conditions()) {
            boolean outcome = evaluateCondition(condition, context);
            checks.add(outcome);
            if (outcome) {
                matched.add(condition.field() + " " + condition.comparator() + " " + condition.value());
            }
        }

        if (rule.groups() != null) {
            for (RuleDslDto group : rule.groups()) {
                checks.add(evaluateGroup(group, context, matched));
            }
        }

        if ("OR".equals(op)) {
            return checks.stream().anyMatch(Boolean::booleanValue);
        }
        return checks.stream().allMatch(Boolean::booleanValue);
    }

    private boolean evaluateCondition(RuleDslDto.ConditionDto condition, Map<String, Object> context) {
        Object actualValue = context.get(condition.field());
        if (actualValue == null) {
            return false;
        }

        String comparator = condition.comparator().trim().toUpperCase(Locale.ROOT);
        String expected = condition.value();

        if (actualValue instanceof Number number) {
            BigDecimal actual = BigDecimal.valueOf(number.doubleValue());
            BigDecimal wanted = new BigDecimal(expected);
            return compareNumeric(actual, wanted, comparator);
        }

        String actualText = String.valueOf(actualValue);
        return switch (comparator) {
            case "=", "==" -> actualText.equalsIgnoreCase(expected);
            case "!=", "<>" -> !actualText.equalsIgnoreCase(expected);
            case "CONTAINS" -> actualText.toLowerCase(Locale.ROOT).contains(expected.toLowerCase(Locale.ROOT));
            default -> false;
        };
    }

    private boolean compareNumeric(BigDecimal actual, BigDecimal wanted, String comparator) {
        return switch (comparator) {
            case ">", "GT" -> actual.compareTo(wanted) > 0;
            case "<", "LT" -> actual.compareTo(wanted) < 0;
            case ">=", "GTE" -> actual.compareTo(wanted) >= 0;
            case "<=", "LTE" -> actual.compareTo(wanted) <= 0;
            case "=", "==" -> actual.compareTo(wanted) == 0;
            case "!=", "<>" -> actual.compareTo(wanted) != 0;
            default -> false;
        };
    }

    private String normalizeOperator(String operator) {
        if (operator == null) {
            return "AND";
        }
        String normalized = operator.trim().toUpperCase(Locale.ROOT);
        return "OR".equals(normalized) ? "OR" : "AND";
    }

    public record RuleEvaluationResult(boolean matched, List<String> matchedClauses) {
    }
}
