package com.tradingapp.risk.dto;

import com.tradingapp.broker.api.OrderSide;
import java.math.BigDecimal;

public record TradePlanDto(
        OrderSide side,
        BigDecimal entry,
        BigDecimal stopLoss,
        BigDecimal target,
        int quantity,
        BigDecimal riskReward
) {
}
