package com.tradingapp.persistence.repositories;

import com.tradingapp.persistence.entities.BacktestTradeEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BacktestTradeRepository extends JpaRepository<BacktestTradeEntity, Long> {
    List<BacktestTradeEntity> findByRunId(Long runId);
}
