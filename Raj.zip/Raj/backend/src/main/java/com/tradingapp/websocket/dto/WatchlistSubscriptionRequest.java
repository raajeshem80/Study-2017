package com.tradingapp.websocket.dto;

import java.util.List;

public record WatchlistSubscriptionRequest(
        String broker,
        List<String> symbols
) {
}
