package com.tradingapp.indicator.calculators;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

public class RsiCalculator {

    public BigDecimal calculate(List<BigDecimal> closes, int period) {
        if (closes == null || closes.size() <= period) {
            return BigDecimal.ZERO;
        }

        double gain = 0.0;
        double loss = 0.0;
        for (int i = 1; i <= period; i++) {
            double delta = closes.get(i).doubleValue() - closes.get(i - 1).doubleValue();
            if (delta >= 0) {
                gain += delta;
            } else {
                loss += Math.abs(delta);
            }
        }

        double avgGain = gain / period;
        double avgLoss = loss / period;

        for (int i = period + 1; i < closes.size(); i++) {
            double delta = closes.get(i).doubleValue() - closes.get(i - 1).doubleValue();
            double currentGain = Math.max(delta, 0);
            double currentLoss = Math.max(-delta, 0);
            avgGain = ((avgGain * (period - 1)) + currentGain) / period;
            avgLoss = ((avgLoss * (period - 1)) + currentLoss) / period;
        }

        if (avgLoss == 0) {
            return BigDecimal.valueOf(100.0);
        }
        double rs = avgGain / avgLoss;
        double rsi = 100.0 - (100.0 / (1.0 + rs));
        return BigDecimal.valueOf(rsi).setScale(4, RoundingMode.HALF_UP);
    }
}
