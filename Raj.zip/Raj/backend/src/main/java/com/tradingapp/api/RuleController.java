package com.tradingapp.api;

import com.tradingapp.api.dto.RuleEvaluateRequest;
import com.tradingapp.api.dto.RuleEvaluateResponse;
import com.tradingapp.strategy.RuleDslEvaluator;
import com.tradingapp.strategy.StrategyRuleService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/rules")
public class RuleController {

    private final StrategyRuleService strategyRuleService;

    public RuleController(StrategyRuleService strategyRuleService) {
        this.strategyRuleService = strategyRuleService;
    }

    @PostMapping("/evaluate")
    public RuleEvaluateResponse evaluate(@Valid @RequestBody RuleEvaluateRequest request) {
        RuleDslEvaluator.RuleEvaluationResult result = strategyRuleService.evaluateAndSave(request);
        return new RuleEvaluateResponse(result.matched(), result.matchedClauses());
    }
}
