package com.tradingapp.execution;

import com.tradingapp.broker.api.BrokerClient;
import com.tradingapp.broker.api.BrokerName;
import com.tradingapp.broker.api.OrderSnapshot;
import com.tradingapp.broker.api.OrderStatus;
import com.tradingapp.broker.api.PlaceOrderCommand;
import com.tradingapp.broker.routing.BrokerRouter;
import com.tradingapp.execution.dto.OrderResponse;
import com.tradingapp.execution.dto.PlaceOrderRequest;
import com.tradingapp.persistence.entities.TradeEntity;
import com.tradingapp.persistence.repositories.TradeRepository;
import com.tradingapp.symbol.SymbolMappingService;
import com.tradingapp.websocket.MarketStreamPublisher;
import com.tradingapp.websocket.dto.OrderWsMessage;
import java.time.Instant;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderExecutionService {

    private final BrokerRouter brokerRouter;
    private final SymbolMappingService symbolMappingService;
    private final OrderGuardService orderGuardService;
    private final TradeRepository tradeRepository;
    private final MarketStreamPublisher marketStreamPublisher;

    public OrderExecutionService(
            BrokerRouter brokerRouter,
            SymbolMappingService symbolMappingService,
            OrderGuardService orderGuardService,
            TradeRepository tradeRepository,
            MarketStreamPublisher marketStreamPublisher
    ) {
        this.brokerRouter = brokerRouter;
        this.symbolMappingService = symbolMappingService;
        this.orderGuardService = orderGuardService;
        this.tradeRepository = tradeRepository;
        this.marketStreamPublisher = marketStreamPublisher;
    }

    @Transactional
    public OrderResponse placeOrder(PlaceOrderRequest request) {
        orderGuardService.validateAccount(request.accountId());
        BrokerClient brokerClient = brokerRouter.route(request.broker());
        BrokerName brokerName = brokerClient.brokerName();
        String brokerSymbol = symbolMappingService.resolveBrokerSymbol(brokerName, request.symbol());

        String orderId;
        OrderStatus status;
        String message;
        if (orderGuardService.dryRunEnabled()) {
            orderId = "DRY-" + System.currentTimeMillis();
            status = OrderStatus.RECEIVED;
            message = "Dry run mode is enabled. Order not sent to broker.";
        } else {
            orderId = brokerClient.placeOrder(new PlaceOrderCommand(
                    request.accountId(),
                    brokerSymbol,
                    request.side(),
                    request.quantity(),
                    request.orderType(),
                    request.price()
            ));
            status = OrderStatus.PLACED;
            message = "Order placed with broker";
        }

        persistTrade(orderId, request, status, message);
        publishOrderEvent(request.broker(), request.accountId(), orderId, status, message);
        return new OrderResponse(orderId, request.broker(), request.accountId(), status, message, Instant.now());
    }

    @Transactional
    public OrderResponse cancelOrder(String broker, String orderId, String accountId) {
        orderGuardService.validateAccount(accountId);
        BrokerClient brokerClient = brokerRouter.route(broker);
        if (!orderGuardService.dryRunEnabled()) {
            brokerClient.cancelOrder(orderId, accountId);
        }

        TradeEntity tradeEntity = tradeRepository.findByOrderId(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Order not found: " + orderId));
        tradeEntity.setStatus(OrderStatus.CANCELLED.name());
        tradeEntity.setUpdatedAt(Instant.now());
        tradeEntity.setMessageText("Order cancelled");
        tradeRepository.save(tradeEntity);

        publishOrderEvent(broker, accountId, orderId, OrderStatus.CANCELLED, "Order cancelled");
        return new OrderResponse(orderId, broker, accountId, OrderStatus.CANCELLED, "Order cancelled", Instant.now());
    }

    public OrderResponse getOrder(String broker, String orderId, String accountId) {
        orderGuardService.validateAccount(accountId);
        BrokerClient brokerClient = brokerRouter.route(broker);
        OrderSnapshot snapshot = brokerClient.getOrder(orderId, accountId);
        return new OrderResponse(
                snapshot.orderId(),
                broker,
                accountId,
                snapshot.status(),
                snapshot.message(),
                snapshot.updatedAt()
        );
    }

    private void persistTrade(String orderId, PlaceOrderRequest request, OrderStatus status, String message) {
        TradeEntity entity = new TradeEntity();
        entity.setOrderId(orderId);
        entity.setBroker(request.broker());
        entity.setAccountId(request.accountId());
        entity.setSymbol(request.symbol());
        entity.setSide(request.side().name());
        entity.setQuantity(request.quantity());
        entity.setPrice(request.price());
        entity.setStatus(status.name());
        entity.setMessageText(message);
        entity.setCreatedAt(Instant.now());
        entity.setUpdatedAt(Instant.now());
        tradeRepository.save(entity);
    }

    private void publishOrderEvent(String broker, String accountId, String orderId, OrderStatus status, String message) {
        marketStreamPublisher.publishOrder(accountId, new OrderWsMessage(
                "v1",
                broker,
                accountId,
                orderId,
                status,
                message,
                Instant.now()
        ));
    }
}
