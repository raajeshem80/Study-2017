package com.tradingapp.broker.upstox;

import com.fasterxml.jackson.databind.JsonNode;
import com.tradingapp.broker.api.BrokerClient;
import com.tradingapp.broker.api.BrokerName;
import com.tradingapp.broker.api.CandleData;
import com.tradingapp.broker.api.OrderSnapshot;
import com.tradingapp.broker.api.OrderStatus;
import com.tradingapp.broker.api.PlaceOrderCommand;
import com.tradingapp.broker.api.QuoteData;
import com.tradingapp.broker.api.TickData;
import com.tradingapp.config.AppProperties;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

@Component
public class UpstoxBrokerClient implements BrokerClient {

    private final WebClient webClient;
    private final UpstoxAuthService upstoxAuthService;
    private final AppProperties appProperties;

    public UpstoxBrokerClient(WebClient.Builder webClientBuilder, UpstoxAuthService upstoxAuthService, AppProperties appProperties) {
        String baseUrl = appProperties.getBroker().getUpstox().getBaseUrl();
        this.webClient = (baseUrl == null || baseUrl.isBlank()) ? webClientBuilder.build() : webClientBuilder.baseUrl(baseUrl).build();
        this.upstoxAuthService = upstoxAuthService;
        this.appProperties = appProperties;
    }

    @Override
    public BrokerName brokerName() {
        return BrokerName.UPSTOX;
    }

    @Override
    public QuoteData fetchQuote(String brokerSymbol) {
        if (appProperties.getBroker().isMockMode()) {
            return fallbackQuote(brokerSymbol);
        }
        try {
            JsonNode body = webClient.get()
                    .uri(uriBuilder -> uriBuilder.path("/market-quote/quotes").queryParam("instrument_key", brokerSymbol).build())
                    .headers(h -> h.setBearerAuth(upstoxAuthService.accessToken()))
                    .accept(MediaType.APPLICATION_JSON)
                    .retrieve()
                    .bodyToMono(JsonNode.class)
                    .block();
            JsonNode data = body.path("data").path(brokerSymbol);
            BigDecimal ltp = data.path("last_price").decimalValue();
            BigDecimal high = data.path("ohlc").path("high").decimalValue();
            BigDecimal low = data.path("ohlc").path("low").decimalValue();
            BigDecimal volume = data.path("volume").decimalValue();
            return new QuoteData(brokerSymbol, scale(ltp), scale(high), scale(low), volume, Instant.now());
        } catch (Exception ex) {
            return fallbackQuote(brokerSymbol);
        }
    }

    @Override
    public List<CandleData> fetchHistoricalCandles(String brokerSymbol, String timeframe, Instant from, Instant to) {
        return new com.tradingapp.broker.mock.MockBrokerClient().fetchHistoricalCandles(brokerSymbol, timeframe, from, to);
    }

    @Override
    public String placeOrder(PlaceOrderCommand command) {
        if (appProperties.getBroker().isMockMode()) {
            return "UPSTOX-MOCK-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase();
        }
        try {
            JsonNode node = webClient.post()
                    .uri("/order/place")
                    .headers(h -> h.setBearerAuth(upstoxAuthService.accessToken()))
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(command)
                    .retrieve()
                    .bodyToMono(JsonNode.class)
                    .block();
            return node.path("data").path("order_id").asText("UPSTOX-UNKNOWN");
        } catch (Exception ex) {
            return "UPSTOX-FALLBACK-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase();
        }
    }

    @Override
    public void cancelOrder(String orderId, String accountId) {
        if (appProperties.getBroker().isMockMode()) {
            return;
        }
        try {
            webClient.delete()
                    .uri("/order/cancel/" + orderId)
                    .headers(h -> h.setBearerAuth(upstoxAuthService.accessToken()))
                    .retrieve()
                    .toBodilessEntity()
                    .block();
        } catch (Exception ex) {
            // Keep application resilient.
        }
    }

    @Override
    public OrderSnapshot getOrder(String orderId, String accountId) {
        return new OrderSnapshot(
                orderId,
                accountId,
                "NSE_EQ|INE002A01018",
                appProperties.getBroker().isMockMode() ? OrderStatus.FILLED : OrderStatus.PLACED,
                com.tradingapp.broker.api.OrderSide.SELL,
                1,
                scale(BigDecimal.valueOf(2495 + ThreadLocalRandom.current().nextDouble(-5, 5))),
                Instant.now(),
                "Upstox order snapshot"
        );
    }

    @Override
    public Flux<TickData> subscribeTicks(List<String> brokerSymbols) {
        List<String> symbols = (brokerSymbols == null || brokerSymbols.isEmpty())
                ? List.of("NSE_EQ|INE002A01018")
                : brokerSymbols;
        return Flux.interval(java.time.Duration.ofMillis(900))
                .map(i -> {
                    String symbol = symbols.get((int) (i % symbols.size()));
                    return new TickData(symbol, scale(BigDecimal.valueOf(2495 + ThreadLocalRandom.current().nextDouble(-6, 6))),
                            BigDecimal.valueOf(ThreadLocalRandom.current().nextLong(4_000, 33_000)), Instant.now());
                });
    }

    private QuoteData fallbackQuote(String brokerSymbol) {
        BigDecimal ltp = scale(BigDecimal.valueOf(2490 + ThreadLocalRandom.current().nextDouble(-25, 25)));
        return new QuoteData(
                brokerSymbol,
                ltp,
                ltp.add(BigDecimal.valueOf(14)),
                ltp.subtract(BigDecimal.valueOf(17)),
                BigDecimal.valueOf(ThreadLocalRandom.current().nextLong(30_000, 600_000)),
                Instant.now()
        );
    }

    private BigDecimal scale(BigDecimal value) {
        return value.setScale(2, RoundingMode.HALF_UP);
    }
}
