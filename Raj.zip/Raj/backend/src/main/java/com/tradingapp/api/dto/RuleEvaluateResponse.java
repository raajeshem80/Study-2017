package com.tradingapp.api.dto;

import java.util.List;

public record RuleEvaluateResponse(
        boolean matched,
        List<String> matchedClauses
) {
}
