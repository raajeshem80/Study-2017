package com.tradingapp.broker.api;

import java.math.BigDecimal;
import java.time.Instant;

public record TickData(
        String brokerSymbol,
        BigDecimal lastPrice,
        BigDecimal volume,
        Instant timestamp
) {
}
