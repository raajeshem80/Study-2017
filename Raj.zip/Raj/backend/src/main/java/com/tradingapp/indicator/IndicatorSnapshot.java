package com.tradingapp.indicator;

import java.math.BigDecimal;

public record IndicatorSnapshot(
        BigDecimal ema50,
        BigDecimal rsi14,
        BigDecimal vwap,
        BigDecimal atr14
) {
}
