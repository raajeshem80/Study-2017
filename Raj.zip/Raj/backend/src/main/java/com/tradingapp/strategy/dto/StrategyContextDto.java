package com.tradingapp.strategy.dto;

import com.tradingapp.candlepattern.CandlestickPattern;
import java.math.BigDecimal;

public record StrategyContextDto(
        String broker,
        String symbol,
        BigDecimal price,
        boolean trendBullish,
        boolean trendBearish,
        boolean nearSupport,
        boolean nearResistance,
        CandlestickPattern pattern,
        BigDecimal rsi,
        BigDecimal vwap,
        BigDecimal atr,
        BigDecimal latestVolume,
        BigDecimal averageVolume
) {
}
