package com.tradingapp.config;

import com.tradingapp.execution.OrderGuardInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class SecurityGuardConfig implements WebMvcConfigurer {

    private final OrderGuardInterceptor orderGuardInterceptor;

    public SecurityGuardConfig(OrderGuardInterceptor orderGuardInterceptor) {
        this.orderGuardInterceptor = orderGuardInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(orderGuardInterceptor).addPathPatterns("/api/orders/**");
    }
}
