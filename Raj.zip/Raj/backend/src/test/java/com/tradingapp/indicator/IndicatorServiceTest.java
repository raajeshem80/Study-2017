package com.tradingapp.indicator;

import com.tradingapp.broker.api.CandleData;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class IndicatorServiceTest {

    private final IndicatorService indicatorService = new IndicatorService();

    @Test
    void shouldCalculateDefaultIndicators() {
        List<CandleData> candles = generateCandles(80, 100.0);
        IndicatorSnapshot snapshot = indicatorService.calculateDefaults(candles);

        Assertions.assertTrue(snapshot.ema50().compareTo(BigDecimal.ZERO) > 0);
        Assertions.assertTrue(snapshot.rsi14().compareTo(BigDecimal.ZERO) >= 0);
        Assertions.assertTrue(snapshot.vwap().compareTo(BigDecimal.ZERO) > 0);
        Assertions.assertTrue(snapshot.atr14().compareTo(BigDecimal.ZERO) >= 0);
    }

    private List<CandleData> generateCandles(int count, double seed) {
        List<CandleData> candles = new ArrayList<>();
        double price = seed;
        Instant t = Instant.parse("2025-01-01T09:15:00Z");
        for (int i = 0; i < count; i++) {
            double open = price;
            double close = open + (i % 2 == 0 ? 1.2 : -0.8);
            double high = Math.max(open, close) + 0.5;
            double low = Math.min(open, close) - 0.5;
            candles.add(new CandleData(t.plusSeconds(i * 300L),
                    BigDecimal.valueOf(open),
                    BigDecimal.valueOf(high),
                    BigDecimal.valueOf(low),
                    BigDecimal.valueOf(close),
                    BigDecimal.valueOf(10000 + i * 100),
                    "5m"));
            price = close;
        }
        return candles;
    }
}
