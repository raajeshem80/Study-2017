package com.tradingapp.risk;

import com.tradingapp.broker.api.OrderSide;
import com.tradingapp.risk.dto.TradePlanDto;
import java.math.BigDecimal;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class RiskEngineServiceTest {

    private final RiskEngineService riskEngineService = new RiskEngineService();

    @Test
    void shouldCalculateAtrBasedSlTpAndPositionSizing() {
        TradePlanDto plan = riskEngineService.buildPlan(
                OrderSide.BUY,
                BigDecimal.valueOf(100_000),
                BigDecimal.valueOf(2500),
                BigDecimal.valueOf(20)
        );

        Assertions.assertEquals(BigDecimal.valueOf(2470.00).setScale(2), plan.stopLoss());
        Assertions.assertEquals(BigDecimal.valueOf(2560.00).setScale(2), plan.target());
        Assertions.assertTrue(plan.quantity() >= 1);
        Assertions.assertTrue(plan.riskReward().compareTo(BigDecimal.valueOf(2.0)) >= 0);
    }

    @Test
    void shouldFallbackWhenAtrIsZero() {
        TradePlanDto plan = riskEngineService.buildPlan(
                OrderSide.SELL,
                BigDecimal.valueOf(10_000),
                BigDecimal.valueOf(100),
                BigDecimal.ZERO
        );
        Assertions.assertTrue(plan.quantity() >= 1);
        Assertions.assertTrue(plan.stopLoss().compareTo(BigDecimal.ZERO) > 0);
    }
}
