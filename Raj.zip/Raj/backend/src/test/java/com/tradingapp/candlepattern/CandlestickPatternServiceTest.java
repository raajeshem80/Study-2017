package com.tradingapp.candlepattern;

import com.tradingapp.broker.api.CandleData;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class CandlestickPatternServiceTest {

    private final CandlestickPatternService service = new CandlestickPatternService();

    @Test
    void shouldDetectBullishEngulfing() {
        CandleData prev = candle(100, 102, 95, 96);
        CandleData last = candle(95, 105, 94, 104);
        CandlestickPattern pattern = service.detect(List.of(prev, last));
        Assertions.assertEquals(CandlestickPattern.BULLISH_ENGULFING, pattern);
    }

    @Test
    void shouldDetectDoji() {
        CandleData prev = candle(100, 103, 99, 101);
        CandleData last = candle(100, 102, 98, 100.1);
        CandlestickPattern pattern = service.detect(List.of(prev, last));
        Assertions.assertEquals(CandlestickPattern.DOJI, pattern);
    }

    private CandleData candle(double open, double high, double low, double close) {
        return new CandleData(
                Instant.parse("2025-01-01T09:15:00Z"),
                BigDecimal.valueOf(open),
                BigDecimal.valueOf(high),
                BigDecimal.valueOf(low),
                BigDecimal.valueOf(close),
                BigDecimal.valueOf(1000),
                "5m"
        );
    }
}
