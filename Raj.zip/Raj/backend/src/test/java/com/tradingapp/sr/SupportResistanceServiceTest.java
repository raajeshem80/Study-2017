package com.tradingapp.sr;

import com.tradingapp.broker.api.CandleData;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class SupportResistanceServiceTest {

    private final SupportResistanceService service = new SupportResistanceService();

    @Test
    void shouldCalculatePivotAndSwings() {
        List<CandleData> candles = List.of(
                candle(100, 105, 98, 102),
                candle(102, 108, 101, 107),
                candle(107, 110, 104, 105)
        );

        SupportResistanceLevels levels = service.calculateLevels(candles);
        Assertions.assertTrue(levels.pivot().compareTo(BigDecimal.ZERO) > 0);
        Assertions.assertTrue(levels.swingLow().compareTo(levels.swingHigh()) < 0);
    }

    private CandleData candle(double open, double high, double low, double close) {
        return new CandleData(
                Instant.parse("2025-01-01T09:15:00Z"),
                BigDecimal.valueOf(open),
                BigDecimal.valueOf(high),
                BigDecimal.valueOf(low),
                BigDecimal.valueOf(close),
                BigDecimal.valueOf(1000),
                "15m"
        );
    }
}
