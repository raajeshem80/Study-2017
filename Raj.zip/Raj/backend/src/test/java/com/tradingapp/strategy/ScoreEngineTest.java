package com.tradingapp.strategy;

import com.tradingapp.candlepattern.CandlestickPattern;
import com.tradingapp.strategy.dto.SignalAction;
import com.tradingapp.strategy.dto.StrategyContextDto;
import java.math.BigDecimal;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ScoreEngineTest {

    private final ScoreEngine scoreEngine = new ScoreEngine();

    @Test
    void shouldReturnBuyWhenScoreAboveThreshold() {
        StrategyContextDto context = new StrategyContextDto(
                "KITE",
                "RELIANCE",
                BigDecimal.valueOf(2500),
                true,
                false,
                true,
                false,
                CandlestickPattern.BULLISH_ENGULFING,
                BigDecimal.valueOf(62),
                BigDecimal.valueOf(2480),
                BigDecimal.valueOf(18),
                BigDecimal.valueOf(120000),
                BigDecimal.valueOf(100000)
        );
        ScoreEngine.ScoreResult result = scoreEngine.score(context);
        Assertions.assertEquals(SignalAction.BUY, result.action());
        Assertions.assertTrue(result.score() >= 75);
    }

    @Test
    void shouldReturnAvoidWhenWeakContext() {
        StrategyContextDto context = new StrategyContextDto(
                "KITE",
                "RELIANCE",
                BigDecimal.valueOf(2500),
                false,
                false,
                false,
                false,
                CandlestickPattern.NONE,
                BigDecimal.valueOf(50),
                BigDecimal.valueOf(2500),
                BigDecimal.valueOf(18),
                BigDecimal.valueOf(50000),
                BigDecimal.valueOf(100000)
        );
        ScoreEngine.ScoreResult result = scoreEngine.score(context);
        Assertions.assertEquals(SignalAction.AVOID, result.action());
    }
}
