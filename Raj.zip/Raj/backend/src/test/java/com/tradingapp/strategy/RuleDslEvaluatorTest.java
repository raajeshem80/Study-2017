package com.tradingapp.strategy;

import com.tradingapp.strategy.dto.RuleDslDto;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class RuleDslEvaluatorTest {

    private final RuleDslEvaluator evaluator = new RuleDslEvaluator();

    @Test
    void shouldEvaluateSimpleAndGroup() {
        RuleDslDto rule = new RuleDslDto(
                "AND",
                List.of(
                        new RuleDslDto.ConditionDto("rsi", ">", "55"),
                        new RuleDslDto.ConditionDto("volume", ">", "100000")
                ),
                List.of(new RuleDslDto(
                        "OR",
                        List.of(new RuleDslDto.ConditionDto("pattern", "==", "HAMMER")),
                        List.of()
                ))
        );

        Map<String, Object> context = Map.of(
                "rsi", 60,
                "volume", 120000,
                "pattern", "HAMMER"
        );
        RuleDslEvaluator.RuleEvaluationResult result = evaluator.evaluate(rule, context);
        Assertions.assertTrue(result.matched());
        Assertions.assertFalse(result.matchedClauses().isEmpty());
    }
}
