# Full-Stack Trading Platform

Production-style monorepo with:

- `backend`: Spring Boot 3.5.2, Java 21, REST + STOMP WebSocket, Kite/Upstox + mock broker mode, strategy/risk/backtest engines, PostgreSQL + Flyway.
- `frontend`: Angular 18 (NgModule-based), Angular Material dashboard, TradingView widget, scanner/signal/trade-plan/rule builder/backtest panels.

## Project Structure

```text
.
├── backend
│   ├── pom.xml
│   ├── .env.example
│   └── src
│       ├── main/java/com/tradingapp (config, broker, strategy, risk, execution, backtest, api, websocket, persistence, infra)
│       ├── main/resources (application.yml, Flyway migrations)
│       └── test/java/com/tradingapp (indicator/risk/strategy/sr tests)
├── frontend
│   ├── package.json
│   ├── angular.json
│   └── src/app (NgModules + components + services + models)
└── docker-compose.yml
```

## Prerequisites

- Java 21
- Maven 3.9+
- Node.js 20+
- npm 10+
- Angular CLI 18 (`npm i -g @angular/cli@18`)
- Docker (for local PostgreSQL)

## Quick Start

1. Start infrastructure:

```bash
docker compose up -d
```

2. Backend setup:

```bash
cd backend
cp .env.example .env
# export vars from .env (or set in shell/IDE)
mvn spring-boot:run
```

3. Frontend setup:

```bash
cd frontend
npm install
npm start
```

4. Open:

- UI: `http://localhost:4200`
- Backend: `http://localhost:8080`
- WebSocket endpoint: `ws://localhost:8080/ws`

## Key APIs

- `GET /api/live/{broker}/{symbol}`
- `POST /api/rules/evaluate`
- `POST /api/backtest`
- `POST /api/orders/place`
- `POST /api/orders/{orderId}/cancel?broker=...&accountId=...`
- `GET /api/orders/{orderId}?broker=...&accountId=...`
- `GET /api/symbols/map/{uiSymbol}`

Order endpoints require header:

- `X-API-KEY: <ORDER_API_KEY>`

## WebSocket Topics

- `/topic/ticks.{symbol}`
- `/topic/signals.{symbol}`
- `/topic/tradeplan.{symbol}`
- `/topic/orders.{account}`

Client app destination:

- `/app/watchlist`

## Environment Configuration

Main backend config is in `backend/src/main/resources/application.yml`.

Important runtime keys:

- `BROKER_MOCK_MODE=true|false`
- `ORDER_KILL_SWITCH=true|false`
- `ORDER_DRY_RUN=true|false`
- `ORDER_API_KEY=...`
- `ORDER_IP_ALLOWLIST=...`
- `ORDER_ACCOUNT_ALLOWLIST=...`
- `APP_CRYPTO_KEY=<16+ char secret>`
- `KITE_*` / `UPSTOX_*` credentials and endpoints

Frontend environment:

- `frontend/src/environments/environment.ts`
- `frontend/src/environments/environment.prod.ts`

## Testing

Backend:

```bash
cd backend
mvn test
```

Frontend:

```bash
cd frontend
npm test
```

## Notes

- Live broker clients are scaffolded with resilient fallback paths and mock mode for local development.
- Rule builder persists/evaluates JSON DSL.
- Trade plan uses fixed risk logic: 1% capital risk + ATR-based SL/TP.
- Backtesting computes win rate, net PnL, max drawdown, expectancy.
